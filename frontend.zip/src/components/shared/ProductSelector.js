import React, { useState, useMemo, useRef } from 'react';

export function ProductSelector({
  products,
  value,
  onChange,
  onBarcodeScan,
  autoFocus = false,
}) {
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [scanStatus, setScanStatus] = useState(null);
  const scanInProgress = useRef(false);
  const searchInputRef = useRef(null);

  const selected = products.find(
    (p) => String(p.id || p._id) === String(value)
  );

  const filtered = useMemo(() => {
    if (!search) return products.slice(0, 20);

    const q = search.toLowerCase();

    return products
      .filter(
        (p) =>
          p.name?.toLowerCase().includes(q) ||
          p.code?.toLowerCase().includes(q) ||
          p.barcode?.toLowerCase().includes(q) ||
          p.sku?.toLowerCase().includes(q),
      )
      .slice(0, 20);
  }, [products, search]);

  function select(product) {
    onChange(String(product.id || product._id), product);
    setOpen(false);
    setSearch('');
  }

  async function handleSearchKeyDown(event) {
    if (event.key !== 'Enter' || !onBarcodeScan || !search.trim()) return;
    event.preventDefault();
    event.stopPropagation();
    if (scanInProgress.current) return;

    scanInProgress.current = true;
    setScanStatus({ type: 'loading', message: 'Looking up barcode…' });
    try {
      const result = await onBarcodeScan(search.trim());
      const productName = result?.product?.name || 'Product';
      const variantName = result?.variant?.variantName
        ? ` (${result.variant.variantName})`
        : '';
      setSearch('');
      setScanStatus({
        type: 'success',
        message: `${productName}${variantName} added to purchase items`,
      });
    } catch (error) {
      setScanStatus({
        type: error.status === 404 ? 'notFound' : 'error',
        message:
          error.message ||
          (error.status === 404
            ? 'Barcode not found'
            : 'Barcode lookup failed'),
      });
    } finally {
      scanInProgress.current = false;
      searchInputRef.current?.focus();
    }
  }

  return (
    <div style={{ position: 'relative' }}>
      {onBarcodeScan ? (
        <input
          ref={searchInputRef}
          autoFocus={autoFocus}
          className="invoice-input"
          placeholder={selected?.name || 'Search product or scan barcode…'}
          value={search}
          onChange={(event) => {
            setSearch(event.target.value);
            setScanStatus(null);
            setOpen(true);
          }}
          onClick={() => setOpen(true)}
          onKeyDown={handleSearchKeyDown}
          disabled={scanStatus?.type === 'loading'}
          aria-label="Search product or scan barcode"
        />
      ) : (
        <div
          className="invoice-select"
          style={{
            cursor: 'pointer',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
          onClick={() => setOpen((o) => !o)}
        >
          <span>{selected ? selected.name : 'Select Product...'}</span>

          <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>▼</span>
        </div>
      )}

      {open && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 4px)',
            left: 0,
            right: 0,
            zIndex: 200,
            background: '#fff',
            border: '1px solid #ddd',
            borderRadius: 8,
            overflow: 'hidden',
            boxShadow: '0 8px 20px rgba(0,0,0,.12)',
          }}
        >
          {!onBarcodeScan && (
            <div style={{ padding: 8 }}>
              <input
                autoFocus
                className="invoice-input"
                placeholder="Search product..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setScanStatus(null);
                }}
                aria-label="Search product"
              />
            </div>
          )}

          {scanStatus && (
            <div
              className={
                scanStatus.type === 'error' || scanStatus.type === 'notFound'
                  ? 'um-error-text'
                  : 'form-hint'
              }
              role={
                scanStatus.type === 'error' || scanStatus.type === 'notFound'
                  ? 'alert'
                  : 'status'
              }
              aria-live="polite"
              style={{ padding: '0 8px 8px' }}
            >
              {scanStatus.type === 'loading' && '⏳ '}
              {scanStatus.type === 'success' && '✓ '}
              {scanStatus.message}
              {scanStatus.type === 'notFound' &&
                ' — edit the text to continue manual product search.'}
            </div>
          )}

          <div
            style={{
              maxHeight: 250,
              overflowY: 'auto',
            }}
          >
            {filtered.length === 0 ? (
              <div style={{ padding: 12 }}>No products found</div>
            ) : (
              filtered.map((p) => (
                <div
                  key={p.id || p._id}
                  onClick={() => select(p)}
                  style={{
                    padding: '10px 12px',
                    cursor: 'pointer',
                  }}
                >
                  <div>{p.name}</div>

                  {p.salePrice && <small>₹{p.salePrice}</small>}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {open && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 199,
          }}
          onClick={() => setOpen(false)}
        />
      )}
    </div>
  );
}
