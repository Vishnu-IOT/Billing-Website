import React from "react";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { ProductSelector } from "./ProductSelector";

const products = [{ id: 1, name: "Tea", code: "TEA-01" }];

describe("ProductSelector barcode search", () => {
  test("looks up scanned text on Enter and reports the matched product", async () => {
    const onBarcodeScan = jest.fn().mockResolvedValue({
      product: { name: "Tea" },
    });

    render(
      <ProductSelector
        products={products}
        value=""
        onChange={jest.fn()}
        onBarcodeScan={onBarcodeScan}
      />,
    );

    const search = screen.getByRole("textbox", {
      name: "Search product or scan barcode",
    });
    fireEvent.change(search, { target: { value: "123456789" } });
    fireEvent.keyDown(search, { key: "Enter", code: "Enter" });

    await waitFor(() => {
      expect(onBarcodeScan).toHaveBeenCalledTimes(1);
      expect(onBarcodeScan).toHaveBeenCalledWith("123456789");
      expect(screen.getByRole("status").textContent).toContain(
        "Tea added to purchase items",
      );
    });
  });

  test("keeps manual product selection available", () => {
    const onChange = jest.fn();
    render(
      <ProductSelector
        products={products}
        value=""
        onChange={onChange}
        onBarcodeScan={jest.fn()}
      />,
    );

    fireEvent.click(
      screen.getByRole("textbox", {
        name: "Search product or scan barcode",
      }),
    );
    fireEvent.click(screen.getByText("Tea"));

    expect(onChange).toHaveBeenCalledWith("1", products[0]);
  });
});
