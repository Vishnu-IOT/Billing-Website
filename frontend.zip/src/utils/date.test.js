import { formatDateForInput, parseDateFromInput } from './date';

describe('DD/MM/YYYY date inputs', () => {
  test('formats API date values for display', () => {
    expect(formatDateForInput('2026-11-12')).toBe('12/11/2026');
    expect(formatDateForInput('2026-11-12T08:30:00.000Z')).toBe('12/11/2026');
  });

  test('parses valid DD/MM/YYYY values to ISO dates', () => {
    expect(parseDateFromInput('12/11/2026')).toBe('2026-11-12');
    expect(parseDateFromInput('1/2/2026')).toBe('2026-02-01');
    expect(parseDateFromInput('2026-11-12')).toBe('2026-11-12');
  });

  test('rejects invalid and ambiguous date values', () => {
    expect(parseDateFromInput('31/02/2026')).toBeNull();
    expect(parseDateFromInput('12/13/2026')).toBeNull();
    expect(parseDateFromInput('12/11/26')).toBeNull();
    expect(parseDateFromInput('')).toBe('');
  });
});
