import { fetchProductBatchesAPI } from '../api/products';

const BATCH_CACHE_TTL_MS = 10000;
const batchCache = new Map();

export function loadBatchesCached(
  productId,
  { availableOnly = false, includeBatchId } = {},
) {
  const key = `${productId}:${availableOnly ? 'available' : 'all'}:${includeBatchId || ''}`;
  const hit = batchCache.get(key);
  if (hit && Date.now() - hit.at < BATCH_CACHE_TTL_MS) return hit.promise;
  const promise = fetchProductBatchesAPI(productId, {
    availableOnly,
    includeBatchId,
  }).catch((error) => {
    batchCache.delete(key);
    throw error;
  });
  batchCache.set(key, { at: Date.now(), promise });
  return promise;
}

export function invalidateBatchCache(productId) {
  if (productId === undefined) batchCache.clear();
  else {
    for (const key of batchCache.keys()) {
      if (key.startsWith(`${productId}:`)) batchCache.delete(key);
    }
  }
}
