import React, { useCallback, useEffect, useMemo, useState } from 'react';
import useAppStore from '../../store/appStore';
import useSettingsStore from '../../store/settingsStore-DB';
import { Button, ToastContainer } from '../../components/ui';
import ThermalSalesReturnBill from '../../components/shared/ThermalSalesReturnBill';
import { useToast } from '../../hooks/useToast';
import { formatCurrency } from '../../utils/currency';
import {
  createSalesReturnCreditAPI,
  fetchReturnableSaleByInvoiceNumberAPI,
} from '../../api/sales';
import { refreshProductsAfterInventoryChange } from '../../store/refreshProductsAfterInventoryChange';

const createIdempotencyKey = () =>
  typeof crypto !== 'undefined' && crypto.randomUUID
    ? crypto.randomUUID()
    : `sales-return-${Date.now()}-${Math.random().toString(36).slice(2)}`;

export default function SalesB2CReturn({ searchParams }) {
  const companies = useAppStore((state) => state.companies);
  const printerWidth = useSettingsStore((state) => state.printerWidth);
  const toast = useToast();
  const company = Array.isArray(companies) ? companies[0] : companies;
  const initialInvoiceNumber = searchParams?.get('invoice') || '';

  const [invoiceNumber, setInvoiceNumber] = useState(initialInvoiceNumber);
  const [invoice, setInvoice] = useState(null);
  const [selectedItems, setSelectedItems] = useState({});
  const [reason, setReason] = useState('');
  const [lookingUp, setLookingUp] = useState(false);
  const [saving, setSaving] = useState(false);
  const [receipt, setReceipt] = useState(null);
  const [idempotencyKey, setIdempotencyKey] = useState('');

  const lookupInvoice = useCallback(async (number) => {
    const invoiceNo = String(number || '').trim();
    if (!invoiceNo) {
      toast.error('Enter the original B2C invoice number');
      return;
    }

    setLookingUp(true);
    setInvoice(null);
    setSelectedItems({});
    setReceipt(null);
    setIdempotencyKey('');
    try {
      const result = await fetchReturnableSaleByInvoiceNumberAPI(invoiceNo);
      setInvoice(result);
      setInvoiceNumber(result.invoiceNumber || invoiceNo);
    } catch (error) {
      toast.error(error.message || 'Could not load the B2C invoice');
    } finally {
      setLookingUp(false);
    }
  }, [toast.error]);

  useEffect(() => {
    if (initialInvoiceNumber) lookupInvoice(initialInvoiceNumber);
  }, [initialInvoiceNumber, lookupInvoice]);

  const chosenItems = useMemo(
    () =>
      (invoice?.items || [])
        .map((item) => {
          const selection = selectedItems[String(item.id)] || {};
          const quantity = Number(selection.quantity);
          if (!Number.isFinite(quantity) || quantity <= 0) return null;
          return {
            saleItemId: item.id,
            quantity,
            quantityUnit: selection.quantityUnit || item.quantityUnit || 'PCS',
          };
        })
        .filter(Boolean),
    [invoice, selectedItems],
  );

  const estimatedCredit = useMemo(
    () =>
      (invoice?.items || []).reduce((total, item) => {
        const selection = selectedItems[String(item.id)] || {};
        const quantity = Number(selection.quantity);
        if (!Number.isFinite(quantity) || quantity <= 0) return total;
        const normalizedQuantity =
          String(selection.quantityUnit || item.quantityUnit).toUpperCase() === 'GRAM'
            ? quantity / 1000
            : quantity;
        const soldQuantity = Number(item.quantity) || 0;
        return soldQuantity > 0
          ? total + (Number(item.netRate) || 0) * normalizedQuantity / soldQuantity
          : total;
      }, 0),
    [invoice, selectedItems],
  );

  function updateSelection(item, patch) {
    setReceipt(null);
    setIdempotencyKey('');
    setSelectedItems((current) => ({
      ...current,
      [String(item.id)]: {
        quantityUnit: item.quantityUnit || item.Product?.baseUnit || 'PCS',
        ...current[String(item.id)],
        ...patch,
      },
    }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    if (!invoice || chosenItems.length === 0) {
      toast.error('Enter a return quantity for at least one item');
      return;
    }
    if (estimatedCredit <= 0) {
      toast.error('Selected items do not have a refundable amount');
      return;
    }

    const key = idempotencyKey || createIdempotencyKey();
    setIdempotencyKey(key);
    setSaving(true);
    try {
      const created = await createSalesReturnCreditAPI(
        invoice.id,
        { items: chosenItems, reason: reason.trim() },
        key,
      );
      setReceipt(created);
      toast.success('Sales return recorded and credit barcode created');
      try {
        await refreshProductsAfterInventoryChange('Sales return');
      } catch (error) {
        console.error('Sales return succeeded, but product stock refresh failed:', error);
        toast.error('Return recorded, but product stock could not be refreshed');
      }
    } catch (error) {
      toast.error(error.message || 'Failed to record sales return');
    } finally {
      setSaving(false);
    }
  }

  function startNewReturn() {
    setReceipt(null);
    setInvoice(null);
    setSelectedItems({});
    setReason('');
    setInvoiceNumber('');
    setIdempotencyKey('');
  }

  return (
    <div className="bills-page">
      <ToastContainer toasts={toast.toasts} />
      <div className="page-header">
        <div className="page-header__left">
          <h1>B2C Sales Return</h1>
          <p className="page-header__sub">
            Find the original invoice, record returned items and issue reusable store credit.
          </p>
        </div>
        <Button variant="ghost" onClick={() => { window.location.hash = 'documents'; }}>
          Back to Documents
        </Button>
      </div>

      <section className="card" style={{ padding: 'var(--sp-4)', marginBottom: 'var(--sp-4)' }}>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            lookupInvoice(invoiceNumber);
          }}
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'flex-end',
            gap: 'var(--sp-3)',
          }}
        >
          <div className="form-group" style={{ flex: '1 1 260px', margin: 0 }}>
            <label className="form-label" htmlFor="sales-return-invoice">
              Original B2C Invoice Number
            </label>
            <input
              id="sales-return-invoice"
              className="form-input"
              value={invoiceNumber}
              onChange={(event) => setInvoiceNumber(event.target.value)}
              placeholder="Scan or enter the invoice number"
              autoComplete="off"
            />
          </div>
          <Button type="submit" variant="primary" disabled={lookingUp}>
            {lookingUp ? 'Searching…' : 'Find Invoice'}
          </Button>
        </form>
      </section>

      {invoice && !receipt && (
        <form onSubmit={handleSubmit}>
          <section className="card" style={{ padding: 'var(--sp-4)', marginBottom: 'var(--sp-4)' }}>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                justifyContent: 'space-between',
                gap: 'var(--sp-3)',
                marginBottom: 'var(--sp-4)',
              }}
            >
              <div>
                <h2 style={{ margin: 0 }}>Invoice {invoice.invoiceNumber}</h2>
                <p className="text-muted" style={{ margin: '4px 0 0' }}>
                  {invoice.customer?.name || 'Walk-in Customer'}
                  {invoice.customer?.phone ? ` · ${invoice.customer.phone}` : ''}
                  {invoice.saleDate
                    ? ` · ${new Date(invoice.saleDate).toLocaleDateString('en-IN')}`
                    : ''}
                </p>
              </div>
              <div style={{ fontWeight: 700 }}>
                Original total: {formatCurrency(invoice.totalAmount)}
              </div>
            </div>

            <div style={{ display: 'grid', gap: 'var(--sp-3)' }}>
              {(invoice.items || []).map((item) => {
                const selection = selectedItems[String(item.id)] || {};
                const isWeight = item.Product?.unitType === 'WEIGHT' ||
                  item.quantityUnit === 'KG';
                const unit = selection.quantityUnit ||
                  item.quantityUnit ||
                  item.Product?.baseUnit ||
                  'PCS';
                const remaining = Number(item.remainingReturnableQuantity) || 0;
                const maxQuantity = unit === 'GRAM' ? remaining * 1000 : remaining;
                const quantity = Number(selection.quantity) || 0;
                const estimate = Number(item.quantity) > 0
                  ? Number(item.netRate || 0) *
                    (unit === 'GRAM' ? quantity / 1000 : quantity) /
                    Number(item.quantity)
                  : 0;
                const isBlocked = Boolean(item.promoApplicationId) ||
                  item.itemRole === 'GIFT';

                return (
                  <div
                    key={item.id}
                    className="card"
                    style={{
                      padding: 'var(--sp-3)',
                      display: 'grid',
                      gridTemplateColumns: 'minmax(160px, 1fr) repeat(3, minmax(110px, auto)) minmax(180px, 1.2fr)',
                      gap: 'var(--sp-3)',
                      alignItems: 'center',
                      opacity: isBlocked || remaining <= 0 ? 0.6 : 1,
                    }}
                  >
                    <div>
                      <strong>{item.productName || item.Product?.name || 'Product'}</strong>
                      {item.batchNo && <div className="text-muted">Batch {item.batchNo}</div>}
                      {isBlocked && (
                        <div className="text-muted">Promotion-linked items cannot be returned.</div>
                      )}
                    </div>
                    <div>
                      <div className="text-muted">Sold</div>
                      <strong>{item.quantity} {item.quantityUnit}</strong>
                    </div>
                    <div>
                      <div className="text-muted">Returned</div>
                      <strong>{item.returnedQuantity} {item.quantityUnit}</strong>
                    </div>
                    <div>
                      <div className="text-muted">Available</div>
                      <strong>{remaining} {item.quantityUnit}</strong>
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label" htmlFor={`return-qty-${item.id}`}>
                        Return quantity {isWeight ? '(KG / GRAM)' : '(PCS)'}
                      </label>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <input
                          id={`return-qty-${item.id}`}
                          className="form-input"
                          type="number"
                          min={isWeight ? '0.001' : '1'}
                          max={maxQuantity}
                          step={isWeight && unit !== 'GRAM' ? '0.001' : '1'}
                          disabled={isBlocked || remaining <= 0 || saving}
                          value={selection.quantity ?? ''}
                          onChange={(event) =>
                            updateSelection(item, { quantity: event.target.value })
                          }
                        />
                        {isWeight && (
                          <select
                            className="form-select"
                            aria-label={`Return quantity unit for ${item.productName}`}
                            value={unit}
                            disabled={isBlocked || remaining <= 0 || saving}
                            onChange={(event) =>
                              updateSelection(item, {
                                quantityUnit: event.target.value,
                                quantity: '',
                              })
                            }
                          >
                            <option value="KG">KG</option>
                            <option value="GRAM">GRAM</option>
                          </select>
                        )}
                      </div>
                      <div className="text-muted" style={{ marginTop: 4 }}>
                        Estimated credit: {formatCurrency(estimate)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="form-group" style={{ marginTop: 'var(--sp-4)' }}>
              <label className="form-label" htmlFor="sales-return-reason">Return reason (optional)</label>
              <input
                id="sales-return-reason"
                className="form-input"
                maxLength={255}
                value={reason}
                disabled={saving}
                onChange={(event) => {
                  setReason(event.target.value);
                  setIdempotencyKey('');
                }}
                placeholder="Reason for return"
              />
            </div>
          </section>

          <section
            className="card"
            style={{
              padding: 'var(--sp-4)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              gap: 'var(--sp-3)',
              flexWrap: 'wrap',
            }}
          >
            <div>
              <div className="text-muted">Estimated return credit</div>
              <strong style={{ fontSize: 'var(--fs-xl)' }}>
                {formatCurrency(estimatedCredit)}
              </strong>
              <div className="text-muted">Credit is based on the original invoice line price.</div>
            </div>
            <Button
              type="submit"
              variant="primary"
              disabled={saving || chosenItems.length === 0 || estimatedCredit <= 0}
            >
              {saving ? 'Recording Return…' : 'Record Return & Create Barcode'}
            </Button>
          </section>
        </form>
      )}

      {receipt && (
        <>
          <ThermalSalesReturnBill
            receipt={receipt}
            company={company}
            printerWidth={printerWidth}
            onPrintError={(message) => toast.error(message)}
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'var(--sp-4)' }}>
            <Button variant="secondary" onClick={startNewReturn}>
              Create Another Return
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
