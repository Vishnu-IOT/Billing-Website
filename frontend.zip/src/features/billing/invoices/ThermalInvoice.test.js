import React from "react";
import { render, screen, within } from "@testing-library/react";
import ThermalInvoice from "./ThermalInvoice";

jest.mock("zustand/react/shallow", () => ({
  useShallow: (selector) => selector,
}));

jest.mock("../../../store/settingsStore-DB", () => ({
  __esModule: true,
  default: (selector) =>
    selector({
      printerWidth: "80",
      defaultTaxRate: 0,
      receiptHeader: "",
      receiptFooter: "",
      showUpiQr: false,
    }),
}));

describe("ThermalInvoice receipt", () => {
  test("renders the reference columns and uses saved bill totals and tax values", () => {
    render(
      <ThermalInvoice
        bill={{
          bill_type: "B2C",
          invoiceNumber: "INV/26-27/001",
          saleDate: "2026-03-20",
          totalAmount: 26.25,
          amountReceived: 30,
          todaySavings: 3.75,
          couponAmount: 1,
          loyaltyPointsEarned: 2,
          loyaltyPointsBalance: 12,
        }}
        companies={{
          name: "AV SUPER MARKET",
          address: "Market Road",
          companyPhone: "9876543210",
          gstin: "GSTIN-123",
        }}
        items={[
          {
            id: "line-1",
            productId: "product-1",
            productName: "Tea",
            quantity: 1,
            paidQuantity: 1,
            price: 25,
            mrp: 30,
            baseRate: 25,
            netRate: 26.25,
            taxPercentage: 5,
            taxAmount: 1.25,
          },
        ]}
        showActionBar={false}
      />,
    );

    expect(screen.getByText("AV SUPER MARKET")).toBeTruthy();
    expect(screen.getByText("CASH BILL")).toBeTruthy();
    const billNumber = screen.getByText("INV/26-27/001");
    expect(billNumber.className).toContain("receipt-reference__bill-number");

    expect(
      screen
        .getAllByText(/^(Bill No:|Time:|Date:|Cashier:)$/)
        .map((label) => label.textContent),
    ).toEqual(["Bill No:", "Time:", "Date:", "Cashier:"]);

    const table = screen.getByRole("table");
    expect(
      within(table)
        .getAllByRole("columnheader")
        .map((header) => header.textContent),
    ).toEqual(["SL", "Description", "MRP", "Rate", "Qty", "Amount"]);

    const itemRow = within(table).getAllByRole("row")[1];
    expect(within(itemRow).getByText("30.00")).toBeTruthy();
    expect(within(itemRow).getByText("26.25")).toBeTruthy();
    expect(within(itemRow).getByText("26")).toBeTruthy();

    expect(screen.getByText("₹26.25")).toBeTruthy();
    expect(screen.getByText("CGST 2.5% =")).toBeTruthy();
    expect(screen.getByText("₹0.63")).toBeTruthy();
    expect(screen.getByText("SGST 2.5% =")).toBeTruthy();
    expect(screen.getByText("₹0.62")).toBeTruthy();
    expect(screen.getByText("Coupon Amount:")).toBeTruthy();
    expect(screen.getByText("Opening Points: 10")).toBeTruthy();
    expect(screen.getByText("Current Points: 12")).toBeTruthy();
    expect(screen.getByText("Today's Savings:")).toBeTruthy();
  });
});
