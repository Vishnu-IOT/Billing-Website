import usePOSStore from './usePOSStore';

jest.mock('../store/settingsStore-DB', () => ({
  __esModule: true,
  default: {
    getState: () => ({
      scannerEnabled: false,
      cameraEnabled: false,
      printerWidth: '80',
      autoPrint: false,
    }),
  },
}));

describe('POS batch allocations', () => {
  beforeEach(() => {
    usePOSStore.getState().clearCart();
  });

  test('splitting a product creates two allocations without changing total quantity', () => {
    const store = usePOSStore.getState();
    store.addCartItemDirect({
      productId: '12',
      productName: 'Rice',
      quantity: 4,
      price: 100,
      mrp: 120,
      productBatchId: '5',
      batchNumber: 'A-1001',
    });

    store.addCartAllocation(usePOSStore.getState().cart[0]);

    const allocations = usePOSStore.getState().cart;
    expect(allocations).toHaveLength(2);
    expect(allocations.map((item) => item.quantity)).toEqual([2, 2]);
    expect(allocations.reduce((total, item) => total + item.quantity, 0)).toBe(4);
    expect(allocations[1]).toMatchObject({
      productId: '12',
      productBatchId: '',
      batchNumber: '',
    });
  });
  test('splitting a line larger than its batch moves exactly the overflow', () => {
    const store = usePOSStore.getState();
    store.addCartItemDirect({
      productId: '12',
      productName: 'Rice',
      quantity: 10,
      price: 100,
      mrp: 120,
      productBatchId: '5',
      batchNumber: 'A-1001',
      batchAvailableQuantity: 7,
    });
    const line = usePOSStore.getState().cart[0];
    usePOSStore.getState().addCartAllocation(line);
    const [first, second] = usePOSStore.getState().cart;
    expect(first.quantity).toBe(7);
    expect(second.quantity).toBe(3);
    expect(second.productBatchId).toBe('');
  });

  test('changing a selected batch rate recalculates the cart amount', () => {
    const store = usePOSStore.getState();
    store.addToCart({
      id: '18',
      name: 'Tea',
      salesPrice: 100,
      taxRate: 0,
    });

    const line = usePOSStore.getState().cart[0];
    store.updateCartItem(line.cartLineId, {
      quantity: 2,
      price: 150,
      productBatchId: '12',
    });

    expect(usePOSStore.getState().cart[0]).toMatchObject({
      price: 150,
      total: 300,
      productBatchId: '12',
    });
  });

  test('adding a fractional weight quantity preserves the requested amount', () => {
    const product = {
      id: '20',
      name: 'Coffee',
      salesPrice: 40,
      unitType: 'WEIGHT',
      taxRate: 0,
    };

    usePOSStore.getState().addToCart(product, 0.5);
    usePOSStore.getState().addToCart(product, 0.25);

    expect(usePOSStore.getState().cart[0]).toMatchObject({
      quantity: 0.75,
      quantityUnit: 'KG',
      total: 30,
    });
  });
});