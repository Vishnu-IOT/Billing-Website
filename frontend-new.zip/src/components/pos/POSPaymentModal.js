import React, { useEffect, useRef, useState } from "react";
import { formatCurrency } from "../../utils/currency";

const PAYMENT_METHODS = [
  { key: "Cash", label: "Cash", icon: "₹", shortcut: "ALT+1" },
  { key: "UPI", label: "UPI QR", icon: "▦", shortcut: "ALT+2" },
  { key: "Card", label: "Card", icon: "▰", shortcut: "ALT+3" },
  { key: "Split", label: "Split", icon: "⇄", shortcut: "ALT+4" },
];

export default function POSPaymentModal({
  open,
  totals,
  paymentMethod,
  onPaymentMethodChange,
  customerInfo,
  invoiceNo,
  saleDate,
  activeShift,
  cashier,
  loyaltyPoints,
  printerWidth,
  autoPrint,
  totalDiscount,
  itemDiscount,
  globalDiscount,
  onConfirm,
  onClose,
  saving,
}) {
  const [cashGiven, setCashGiven] = useState("");
  const [splitCash, setSplitCash] = useState("");
  const [splitCard, setSplitCard] = useState("");
  const [splitUPI, setSplitUPI] = useState("");
  const firstPaymentMethodRef = useRef(null);
  const previousFocusRef = useRef(null);
  const grandTotal = Number(totals?.grandTotal) || 0;

  useEffect(() => {
    if (!open) return undefined;
    previousFocusRef.current = document.activeElement;
    firstPaymentMethodRef.current?.focus();
    return () => {
      if (previousFocusRef.current instanceof HTMLElement) {
        previousFocusRef.current.focus();
      }
    };
  }, [open]);

  const tenderedCash = Number.parseFloat(cashGiven) || 0;
  const change = Math.max(0, tenderedCash - grandTotal);
  const splitTotal =
    (Number.parseFloat(splitCash) || 0) +
    (Number.parseFloat(splitCard) || 0) +
    (Number.parseFloat(splitUPI) || 0);
  const splitRemainder = grandTotal - splitTotal;
  const confirmDisabled =
    saving ||
    (paymentMethod === "Cash" && cashGiven !== "" && tenderedCash < grandTotal) ||
    (paymentMethod === "Split" && Math.abs(splitRemainder) > 0.01);

  const handleConfirmClick = () => {
    let paymentDetails = null;
    let amountReceived = grandTotal;
    if (paymentMethod === "Split") {
      amountReceived = splitTotal;
      paymentDetails = {
        cash: Number.parseFloat(splitCash) || 0,
        card: Number.parseFloat(splitCard) || 0,
        upi: Number.parseFloat(splitUPI) || 0,
      };
    } else if (paymentMethod === "Cash") {
      amountReceived = cashGiven === "" ? grandTotal : tenderedCash;
      paymentDetails = { cash: grandTotal };
    } else if (paymentMethod === "Card") {
      paymentDetails = { card: grandTotal };
    } else if (paymentMethod === "UPI") {
      paymentDetails = { upi: grandTotal };
    }

    onConfirm(paymentDetails, {
      amountReceived,
      amountReturned: paymentMethod === "Cash" ? change : 0,
    });
  };

  if (!open) return null;

  const applyCash = (amount) => {
    setCashGiven(String(amount));
  };
  const terminalId = activeShift?.terminalId || "POS-TERMINAL-1";
  const fiscalDiscount =
    Number(totalDiscount) ||
    Math.max(
      0,
      Number(totals?.rawTotal) -
        Number(totals?.preCreditGrandTotal ?? grandTotal) -
        Number(totals?.roundOff || 0),
    );

  return (
    <div
      className="pos-checkout-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      onKeyDown={(event) => {
        if (event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          onClose();
        } else if (event.key === "F8" || (event.key === "Enter" && event.ctrlKey)) {
          event.preventDefault();
          if (!confirmDisabled) handleConfirmClick();
        } else if (event.altKey && /^[1-4]$/.test(event.key)) {
          event.preventDefault();
          onPaymentMethodChange(PAYMENT_METHODS[Number(event.key) - 1].key);
        }
      }}
    >
      <section
        className="billflow-checkout"
        role="dialog"
        aria-modal="true"
        aria-label="Checkout"
      >
        <header className="billflow-checkout-header">
          <div className="billflow-checkout-identity">
            <span className="billflow-checkout-kicker">CHECKOUT · BILLFLOW POS</span>
            <strong>{invoiceNo}</strong>
            <div className="billflow-checkout-terminal-meta">
              <span>TERMINAL <b>{terminalId}</b></span>
              <span>COUNTER <b>LANE 01</b></span>
              <span>OPERATOR <b>{cashier?.name || cashier?.username || "Cashier"}</b></span>
              <span>SHIFT <b>{activeShift ? `#${activeShift.id}` : "NOT OPEN"}</b></span>
              <span>{saleDate || "Current sale"}</span>
            </div>
          </div>
          <div className="billflow-checkout-payable">
            <span>NET PAYABLE</span>
            <strong>{formatCurrency(grandTotal)}</strong>
          </div>
          <button
            type="button"
            className="billflow-checkout-close"
            onClick={onClose}
            aria-label="Close checkout"
          >
            ×
          </button>
        </header>

        <div className="billflow-checkout-columns">
          <div className="billflow-checkout-tender">
            <section className="billflow-checkout-customer">
              <span className="billflow-checkout-section-title">CUSTOMER IDENTIFICATION</span>
              <div className="billflow-checkout-customer-grid">
                <label>
                  CUSTOMER
                  <strong>{customerInfo?.name || "Walk-in Customer"}</strong>
                </label>
                <label>
                  PHONE
                  <strong>{customerInfo?.phone || "—"}</strong>
                </label>
                <label>
                  LOYALTY
                  <strong>{Number(loyaltyPoints) > 0 ? `${loyaltyPoints} POINTS` : "GUEST"}</strong>
                </label>
              </div>
            </section>

            <section className="billflow-checkout-method-section">
              <span className="billflow-checkout-section-title">PAYMENT METHOD</span>
              <div className="billflow-checkout-methods">
                {PAYMENT_METHODS.map((method) => (
                  <button
                    key={method.key}
                    ref={method.key === "Cash" ? firstPaymentMethodRef : undefined}
                    type="button"
                    className={`billflow-checkout-method ${
                      paymentMethod === method.key ? "is-selected" : ""
                    }`}
                    onClick={() => onPaymentMethodChange(method.key)}
                    aria-pressed={paymentMethod === method.key}
                  >
                    <span className="billflow-checkout-method-icon">{method.icon}</span>
                    <strong>{method.label}</strong>
                    <kbd>{method.shortcut}</kbd>
                  </button>
                ))}
              </div>
            </section>

            {paymentMethod === "Cash" && (
              <section className="billflow-checkout-tender-box">
                <div className="billflow-checkout-section-heading">
                  <span className="billflow-checkout-section-title">CURRENCY RECEIVED</span>
                  <span className="billflow-checkout-due">
                    DUE {formatCurrency(grandTotal)}
                  </span>
                </div>
                <div className="billflow-checkout-cash-matrix">
                  <button type="button" onClick={() => applyCash(grandTotal + 50)}>+ ₹50</button>
                  <button type="button" onClick={() => applyCash(grandTotal + 100)}>+ ₹100</button>
                  <button type="button" onClick={() => applyCash(grandTotal + 500)}>+ ₹500</button>
                  <button type="button" onClick={() => applyCash(grandTotal)}>EXACT AMOUNT</button>
                  <button type="button" onClick={() => applyCash(2000)}>₹2,000</button>
                </div>
                <label className="billflow-checkout-received">
                  <span>TENDERED INR</span>
                  <div>
                    <b>₹</b>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={cashGiven}
                      onChange={(event) => setCashGiven(event.target.value)}
                      placeholder={String(grandTotal.toFixed(2))}
                      aria-label="Amount received in cash"
                    />
                  </div>
                </label>
                <div className="billflow-checkout-change">
                  <span>CHANGE TO RETURN</span>
                  <strong>{formatCurrency(change)}</strong>
                </div>
              </section>
            )}

            {paymentMethod === "Split" && (
              <section className="billflow-checkout-tender-box">
                <span className="billflow-checkout-section-title">SPLIT TENDER</span>
                <div className="billflow-checkout-split-fields">
                  <label>Cash<input type="number" min="0" step="0.01" value={splitCash} onChange={(event) => setSplitCash(event.target.value)} /></label>
                  <label>Card<input type="number" min="0" step="0.01" value={splitCard} onChange={(event) => setSplitCard(event.target.value)} /></label>
                  <label>UPI<input type="number" min="0" step="0.01" value={splitUPI} onChange={(event) => setSplitUPI(event.target.value)} /></label>
                </div>
                <div className={`billflow-checkout-split-status ${Math.abs(splitRemainder) <= 0.01 ? "is-matched" : ""}`}>
                  <span>{Math.abs(splitRemainder) <= 0.01 ? "TENDER MATCHED" : "BALANCE DUE"}</span>
                  <strong>{formatCurrency(Math.max(0, splitRemainder))}</strong>
                </div>
              </section>
            )}
          </div>

          <aside className="billflow-checkout-fiscal">
            <div className="billflow-checkout-fiscal-heading">
              <span className="billflow-checkout-section-title">FISCAL LEDGER</span>
              <span>INR · GST</span>
            </div>
            <div className="billflow-checkout-fiscal-row">
              <span>Basket Subtotal</span>
              <strong>{formatCurrency(totals?.subtotal)}</strong>
            </div>
            {Number(itemDiscount) > 0 && (
              <div className="billflow-checkout-fiscal-row is-discount">
                <span>Item Discount</span>
                <strong>−{formatCurrency(itemDiscount)}</strong>
              </div>
            )}
            {Number(globalDiscount) > 0 && (
              <div className="billflow-checkout-fiscal-row is-discount">
                <span>Bill Discount</span>
                <strong>−{formatCurrency(globalDiscount)}</strong>
              </div>
            )}
            <div className="billflow-checkout-fiscal-row">
              <span>GST Collected</span>
              <strong>{formatCurrency(totals?.totalTax)}</strong>
            </div>
            <div className="billflow-checkout-fiscal-note">
              GST component split is shown on the saved invoice.
            </div>
            {Number(totals?.returnCreditAmount) > 0 && (
              <div className="billflow-checkout-fiscal-row is-credit">
                <span>Return Credit</span>
                <strong>−{formatCurrency(totals.returnCreditAmount)}</strong>
              </div>
            )}
            {Number(loyaltyPoints) > 0 && (
              <div className="billflow-checkout-fiscal-row">
                <span>Loyalty Balance</span>
                <strong>{Number(loyaltyPoints).toLocaleString("en-IN")} pts</strong>
              </div>
            )}
            <div className="billflow-checkout-fiscal-row">
              <span>Round-off Adjustment</span>
              <strong>{formatCurrency(totals?.roundOff)}</strong>
            </div>
            {fiscalDiscount > 0 && (
              <div className="billflow-checkout-savings">
                <span>TOTAL BILL SAVINGS</span>
                <strong>{formatCurrency(fiscalDiscount)}</strong>
              </div>
            )}
            <div className="billflow-checkout-grand-total">
              <span>GRAND TOTAL</span>
              <strong>{formatCurrency(grandTotal)}</strong>
            </div>
          </aside>
        </div>

        <footer className="billflow-checkout-footer">
          <div className="billflow-checkout-device-status">
            <span>PRINTER <b>{autoPrint ? `AUTO · ${printerWidth}mm` : "MANUAL"}</b></span>
            <span>DRAWER <b>NOT CONFIGURED</b></span>
            <span>CHANGE <b>{formatCurrency(change)}</b></span>
          </div>
          <button type="button" className="billflow-checkout-back" onClick={onClose}>
            BACK <kbd>ESC</kbd>
          </button>
          <button
            type="button"
            className="billflow-checkout-confirm"
            onClick={handleConfirmClick}
            disabled={confirmDisabled}
          >
            {saving ? "SAVING BILL…" : <>CONFIRM &amp; PRINT BILL <kbd>F8</kbd></>}
          </button>
        </footer>
      </section>
    </div>
  );
}
