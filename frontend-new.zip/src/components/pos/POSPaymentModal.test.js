import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import POSPaymentModal from './POSPaymentModal';

describe('POSPaymentModal', () => {
  test('keeps cash tender and change calculations intact in the fiscal checkout', () => {
    const onConfirm = jest.fn();
    render(
      <POSPaymentModal
        open
        totals={{
          grandTotal: 125,
          subtotal: 120,
          totalTax: 5,
          rawTotal: 125,
          roundOff: 0,
        }}
        paymentMethod="Cash"
        onPaymentMethodChange={jest.fn()}
        customerInfo={{ name: 'Walk-in Customer', phone: '' }}
        onCustomerChange={jest.fn()}
        invoiceNo="INV/26-27/0001"
        saleDate="2026-11-16"
        onConfirm={onConfirm}
        onClose={jest.fn()}
        saving={false}
      />,
    );

    expect(screen.getByRole('dialog', { name: 'Checkout' })).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: '+ ₹50' }));
    fireEvent.click(
      screen.getByRole('button', { name: /CONFIRM & PRINT BILL/i }),
    );

    expect(onConfirm).toHaveBeenCalledWith(
      { cash: 125 },
      { amountReceived: 175, amountReturned: 50 },
    );
    expect(screen.getAllByText('₹50.00')).toHaveLength(2);
    expect(screen.getByText('FISCAL LEDGER')).toBeTruthy();
    expect(screen.getAllByText('₹125.00').length).toBeGreaterThan(0);
  });

  test('preserves split tender allocations in checkout', () => {
    const onConfirm = jest.fn();
    render(
      <POSPaymentModal
        open
        totals={{ grandTotal: 100, subtotal: 95, totalTax: 5, roundOff: 0 }}
        paymentMethod="Split"
        onPaymentMethodChange={jest.fn()}
        customerInfo={{ name: 'Customer', phone: '9876543210' }}
        invoiceNo="INV/26-27/0002"
        saleDate="2026-11-17"
        onConfirm={onConfirm}
        onClose={jest.fn()}
        saving={false}
      />,
    );

    const tenderInputs = screen.getAllByRole('spinbutton');
    fireEvent.change(tenderInputs[0], { target: { value: '40' } });
    fireEvent.change(tenderInputs[1], { target: { value: '30' } });
    fireEvent.change(tenderInputs[2], { target: { value: '30' } });
    fireEvent.click(
      screen.getByRole('button', { name: /CONFIRM & PRINT BILL/i }),
    );

    expect(onConfirm).toHaveBeenCalledWith(
      { cash: 40, card: 30, upi: 30 },
      { amountReceived: 100, amountReturned: 0 },
    );
  });
});
