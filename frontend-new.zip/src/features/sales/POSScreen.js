/* ===== POS SCREEN — Main B2C POS Layout ===== */
import React, { useState, useCallback, useEffect, useMemo, useRef } from "react";
import {
  FiUser,
  FiFileText,
  FiPauseCircle,
  FiXCircle,
  FiTrash2,
  FiSearch,
  FiCreditCard,
  FiUserCheck,
  FiPrinter,
  FiClock,
  FiLayers,
  FiStar,
} from "react-icons/fi";
import useAppStore from "../../store/appStore";
import useSalesStore from "../../store/salesStore";
import usePOSStore from "../../hooks/usePOSStore";
import useAuthStore from "../../store/authStore";
import useSettingsStore from "../../store/settingsStore-DB";
import usePosStore from "../../store/posStore";
import { formatCurrency } from "../../utils/currency";
import { todayISO } from "../../utils/date";
import {
  getNextInvoiceNo,
  buildSaleBillPayload,
  calcBillTotals,
  calcItemRow,
  applyPromotionPreviewPricing,
  getPromotionBatchAllocationKey,
} from "../../utils/invoice";
import {
  findProduct,
  getDiscountedSalesPrice,
  getProductPricing,
  normalizePriceType,
} from "../../utils/gstPricing";
import {
  fetchSaleBillByIdAPI,
  fetchSalesReturnCreditAPI,
} from "../../api";
import { previewPromotionAPI } from "../../api/promotions";
import { useToast } from "../../hooks/useToast";
import { ToastContainer } from "../../components/ui";
import BarcodeInput from "../../components/pos/BarcodeInput";
import CameraScanner from "../../components/pos/CameraScanner";
import POSCartItem from "../../components/pos/POSCartItem";
import POSPaymentModal from "../../components/pos/POSPaymentModal";
import CashDenominationCounter from "../../components/pos/CashDenominationCounter";
import ThermalBill from "../../components/pos/ThermalBill";
import BatchSelector from "../../components/shared/BatchSelector";
import { invalidateBatchCache } from "../../components/shared/BatchSelector";
import "../../styles/pos-b2c.css";
import "../../styles/POSScreen.css";
// import '../../styles/thermal.css';
import {
  fetchCompanyUsersAPI,
  fetchFinancialDetailsAPI,
  previewNextInvoiceNumberAPI,
} from "../../api";
import ThermalInvoice from "../billing/invoices/ThermalInvoice";
import {
  formatQuantity,
  isWeightProduct,
  normalizeWeightQuantity,
} from "../../utils/quantityUnits";
import {
  getQuantityInProductBaseUnit,
  getProductStockLabel,
  getRemainingProductStock,
} from "../../utils/posStock";
import {
  areDenominationCountsValid,
  createEmptyDenominationCounts,
  getDenominationTotal,
  getExpectedClosingCash,
  normalizeDenominationCounts,
} from "../../utils/posShift";

/* ── Quantity and discount inputs for POS cart rows ── */
function POSQtyInput({
  value,
  onCommit,
  onEnter,
  ariaLabel,
  step = 1,
  allowDecimal = false,
}) {
  const [draft, setDraft] = useState(String(value));

  useEffect(() => {
    setDraft(String(value));
  }, [value]);

  return (
    <input
      type="text"
      inputMode="decimal"
      step={step}
      className="pos-exact-qty-val pos-exact-qty-input"
      aria-label={ariaLabel}
      value={draft}
      onChange={(e) => {
        const v = e.target.value;
        const validPattern = allowDecimal
          ? /^\d*\.?\d{0,3}$/
          : /^\d*$/;
        if (v !== "" && !validPattern.test(v)) return;
        setDraft(v);
        const n = parseFloat(v);
        if (n > 0 && onCommit(n) === false) setDraft(String(value));
      }}
      onFocus={(e) => e.target.select()}
      onBlur={() => {
        if (!(parseFloat(draft) > 0)) setDraft(String(value));
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          e.target.blur();
          if (onEnter) onEnter();
        }
      }}
    />
  );
}

function POSDiscountInput({ value, ariaLabel }) {
  return (
    <div className="pos-exact-discount-control">
      <input
        type="text"
        className="pos-exact-discount-input"
        aria-label={ariaLabel}
        value={Number(value) || 0}
        readOnly
        aria-readonly="true"
      />
      <span>%</span>
    </div>
  );
}

export default function POSScreen({
  editMode = false,
  billId = null,
  onBack,
  onSaved,
}) {
  const products = useAppStore((s) => s.products);
  const categories = useAppStore((s) => s.categories);
  const brands = useAppStore((s) => s.brands);
  const companyRecord = useAppStore((s) => s.companies);
  const companyInfo = Array.isArray(companyRecord)
    ? companyRecord[0] || {}
    : companyRecord || {};
  const companyId = companyInfo.id;
  const billingUser = useAuthStore((s) => s.user);
  const shiftCompanyId = billingUser?.companyId || companyId;
  const settings = useSettingsStore();
  const saleBills = useSalesStore((s) => s.saleBills);
  const addBill = useSalesStore((s) => s.addBill);
  const updateBill = useSalesStore((s) => s.updateBill);
  const toast = useToast();
  const toastError = toast.error;

  /* ── POS Store ── */
  const cart = usePOSStore((s) => s.cart);
  const customerInfo = usePOSStore((s) => s.customerInfo);
  const customers = useAppStore((s) => s.customers);
  const paymentMethod = usePOSStore((s) => s.paymentMethod);
  const globalDiscount = usePOSStore((s) => s.globalDiscount);
  const invoiceNo = usePOSStore((s) => s.invoiceNo);
  const saleDate = usePOSStore((s) => s.saleDate);
  const printerWidth = useSettingsStore((s) => s.printerWidth);
  const autoPrint = useSettingsStore((s) => s.autoPrint);
  const scannerEnabled = useSettingsStore((s) => s.scannerEnabled);
  const addToCart = usePOSStore((s) => s.addToCart);
  const addCartItemDirect = usePOSStore((s) => s.addCartItemDirect);
  const addMultipleCartItemsDirect = usePOSStore(
    (s) => s.addMultipleCartItemsDirect,
  );
  const updateCartItem = usePOSStore((s) => s.updateCartItem);
  const removeFromCart = usePOSStore((s) => s.removeFromCart);
  const clearCart = usePOSStore((s) => s.clearCart);
  const setCustomerInfo = usePOSStore((s) => s.setCustomerInfo);
  const setPaymentMethod = usePOSStore((s) => s.setPaymentMethod);
  const setGlobalDiscount = usePOSStore((s) => s.setGlobalDiscount);
  const setInvoiceNo = usePOSStore((s) => s.setInvoiceNo);

  // getNextInvoiceNo(saleBills, settings) only ever guesses from whatever is
  // currently loaded in the local saleBills store — on a fresh page load, or
  // after a filter/pagination narrows that list, it silently falls back to
  // "1". The backend's running counter is the only source of truth, so fetch
  // and use that instead (same fix already applied to the B2B create form).
  const refreshInvoiceNo = useCallback(async () => {
    try {
      let companyId = 1;
      const erpSettings = localStorage.getItem("erp-settings");
      if (erpSettings) {
        const companydata = JSON.parse(erpSettings);
        companyId = companydata?.state?.companyId || 1;
      }
      const res = await previewNextInvoiceNumberAPI(companyId);
      const realNext = res?.data?.nextInvoiceNumber;
      setInvoiceNo(realNext || getNextInvoiceNo(saleBills, settings));
    } catch {
      // fall back to the local guess only if the backend call fails
      setInvoiceNo(getNextInvoiceNo(saleBills, settings));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saleBills, settings]);
  const setSaleDate = usePOSStore((s) => s.setSaleDate);

  const checkProductStock = useCallback(
    (product, quantity, quantityUnit, excludedCartLineId) => {
      const productId = product?.id || product?._id;
      const remainingStock = getRemainingProductStock(
        cart,
        productId,
        product,
        excludedCartLineId,
      );
      if (remainingStock === null) return true;

      const requestedQuantity = getQuantityInProductBaseUnit(
        quantity,
        quantityUnit,
        product,
      );
      if (requestedQuantity <= remainingStock + 0.000001) return true;

      const available = formatQuantity(Math.max(0, remainingStock));
      const unit = isWeightProduct(product) ? "KG" : "PCS";
      toast.error(
        `Only ${available} ${unit} of ${product.name} remain in total product stock.`,
      );
      return false;
    },
    [cart, toast],
  );

  /* ── Shift & Hold Store ── */
  const storedActiveShift = usePosStore((s) => s.activeShift);
  const activeShift =
    Number(storedActiveShift?.userId) === Number(billingUser?.id) &&
    (!shiftCompanyId ||
      Number(storedActiveShift?.companyId) === Number(shiftCompanyId))
      ? storedActiveShift
      : null;
  const holdCarts = usePosStore((s) => s.holdCarts);
  const checkCurrentShift = usePosStore((s) => s.checkCurrentShift);
  const clearActiveShift = usePosStore((s) => s.clearActiveShift);
  const startShift = usePosStore((s) => s.startShift);
  const endShift = usePosStore((s) => s.endShift);
  const holdCartAction = usePosStore((s) => s.holdCart);
  const loadHoldCarts = usePosStore((s) => s.loadHoldCarts);
  const resumeHoldCart = usePosStore((s) => s.resumeHoldCart);
  const cancelHoldCart = usePosStore((s) => s.cancelHoldCart);

  /* ── Local State ── */
  const [cameraOpen, setCameraOpen] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [lastPrintedBill, setLastPrintedBill] = useState(null);
  const [users, setUsers] = useState([]);
  const [shiftModalOpen, setShiftModalOpen] = useState(false);
  const [openingDenominations, setOpeningDenominations] = useState(
    createEmptyDenominationCounts,
  );
  const [shiftCloseModal, setShiftCloseModal] = useState(false);
  const [closingDenominations, setClosingDenominations] = useState(
    createEmptyDenominationCounts,
  );
  const [shiftCloseConfirmed, setShiftCloseConfirmed] = useState(false);
  const [priceCheckMode, setPriceCheckMode] = useState(false);
  const [holdDrawerOpen, setHoldDrawerOpen] = useState(false);
  const [holdNote, setHoldNote] = useState("");
  const [printReady, setPrintReady] = useState(false);
  const [loyaltyPoints, setLoyaltyPoints] = useState(0);
  const [promotionPreviews, setPromotionPreviews] = useState({});
  const [returnCredit, setReturnCredit] = useState(null);
  const [loadingReturnCredit, setLoadingReturnCredit] = useState(false);

  const pricedCart = useMemo(
    () =>
      cart.map((item) => {
        const hasSelectedBatch = Boolean(item.productBatchId || item.batchId);
        const regularItem = {
          ...item,
          productBatchId: item.productBatchId || item.batchId || "",
          batchId: item.productBatchId || item.batchId || "",
          batchNumber: item.batchNumber || item.batchNo || "",
          batchNo: item.batchNo || item.batchNumber || "",
          expiryDate: item.expiryDate || "",
        };
        const product = findProduct(products, item.productId);
        if (!product) return regularItem;
        const savedPricing = getProductPricing(product, "sales");
        return calcItemRow({
          ...regularItem,
          price: hasSelectedBatch
            ? Number(item.price ?? item.salePrice ?? savedPricing.price)
            : getDiscountedSalesPrice(product),
          priceType: savedPricing.priceType,
          mrp: hasSelectedBatch
            ? Number(item.mrp ?? product.MRP ?? product.mrp) || 0
            : Number(product.MRP ?? product.mrp) || 0,
          discountPercent: hasSelectedBatch
            ? Number(item.discountPercent) || 0
            : 0,
          taxRate: Number(product.taxRate) || 0,
        });
      }),
    [cart, products],
  );

  const promotionPreviewGroups = useMemo(() => {
    const groups = new Map();
    pricedCart.forEach((item) => {
      const product = findProduct(products, item.productId);
      const weightProduct = isWeightProduct(product || item);
      const normalizedQuantity = weightProduct
        ? normalizeWeightQuantity(item.quantity, item.quantityUnit || product?.baseUnit || 'KG')
        : Number(item.quantity) || 0;
      const key = String(item.productId);
      const group = groups.get(key) || {
        productId: item.productId,
        paidQuantity: 0,
        quantityUnit: weightProduct ? 'KG' : 'PCS',
      };
      group.paidQuantity += normalizedQuantity;
      groups.set(key, group);
    });
    return [...groups.values()].map((group) => {
      const productItems = pricedCart.filter(
        (item) => String(item.productId) === String(group.productId),
      );
      const selectedItems = productItems.filter(
        (item) => item.productBatchId || item.batchId,
      );
      const allItemsHaveBatch = selectedItems.length === productItems.length;
      const batchQuantities = new Map();
      if (allItemsHaveBatch) {
        productItems.forEach((item) => {
          const batchId = String(item.productBatchId || item.batchId);
          const product = findProduct(products, item.productId);
          const quantity = isWeightProduct(product || item)
            ? normalizeWeightQuantity(
                item.quantity,
                item.quantityUnit || product?.baseUnit || "KG",
              )
            : Number(item.quantity) || 0;
          batchQuantities.set(
            batchId,
            (batchQuantities.get(batchId) || 0) + quantity,
          );
        });
      }
      return {
        ...group,
        hasMixedBatchSelection:
          selectedItems.length > 0 && !allItemsHaveBatch,
        ...(allItemsHaveBatch &&
          selectedItems.length > 0 && {
            batchAllocations: [...batchQuantities.entries()].map(
              ([batchId, quantity]) => ({ batchId, quantity }),
            ),
          }),
        batchAllocationKey: getPromotionBatchAllocationKey(
          productItems,
        ),
      };
    });
  }, [pricedCart, products]);

  useEffect(() => {
    if (editMode || promotionPreviewGroups.length === 0) {
      setPromotionPreviews({});
      return undefined;
    }

    let active = true;
    const pending = Object.fromEntries(
      promotionPreviewGroups.map((group) => [
        String(group.productId),
        { loading: true, batchAllocationKey: group.batchAllocationKey },
      ]),
    );
    setPromotionPreviews(pending);

    const timer = setTimeout(() => {
      Promise.all(
        promotionPreviewGroups.map(async (group) => {
          if (group.hasMixedBatchSelection) {
            return [String(group.productId), {
              batchAllocationKey: group.batchAllocationKey,
              error: "Select a batch for every line of this product, or clear all batch selections.",
            }];
          }
          try {
            const response = await previewPromotionAPI({
              ...group,
              billType: 'B2C',
              companyId,
              useProductSalesPrice: true,
            });
            return [String(group.productId), {
              batchAllocationKey: group.batchAllocationKey,
              data: response?.data?.data || response?.data || response,
            }];
          } catch (error) {
            return [String(group.productId), {
              batchAllocationKey: group.batchAllocationKey,
              error: error.message,
            }];
          }
        }),
      ).then((entries) => {
        if (active) setPromotionPreviews(Object.fromEntries(entries));
      });
    }, 250);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [editMode, promotionPreviewGroups, companyId]);

  const printRef = useRef(null);

  /* ── Add Item Form State ── */
  const [addItemSearch, setAddItemSearch] = useState("");
  const [addItemProduct, setAddItemProduct] = useState(null);
  const [addItemSuggestions, setAddItemSuggestions] = useState([]);
  const [addItemDropdownOpen, setAddItemDropdownOpen] = useState(false);
  const [addItemHighlightedIndex, setAddItemHighlightedIndex] = useState(-1);
  const formDropdownRef = useRef(null);
  const searchInputRef = useRef(null);
  const cartTableRef = useRef(null);
  const customerPhoneInputRef = useRef(null);
  const customerNameInputRef = useRef(null);

  const [companyFinancials, setCompanyFinancials] = useState({});

  useEffect(() => {
    if (!companyId) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetchFinancialDetailsAPI(companyId);
        const financials = res?.data?.data || res?.data || {};
        if (!cancelled) setCompanyFinancials(financials);
      } catch (err) {
        console.error(
          "Could not load company financial details for receipt:",
          err,
        );
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [companyId]);

  const companyForReceipt = { ...companyInfo, financials: companyFinancials };
  // console.log(companyForReceipt);

  /* ── Init & Edit Mode ── */
  useEffect(() => {
    if (editMode && billId) {
      const existingBill = saleBills.find(
        (b) => String(b.id) === String(billId),
      );

      if (!existingBill) return;

      // console.log("Initializing POS with existing bill:", existingBill);

      clearCart();

      // Invoice details
      setInvoiceNo(existingBill.invoiceNumber || existingBill.invoiceNo || "");

      setSaleDate(
        existingBill.saleDate
          ? existingBill.saleDate.split("T")[0]
          : todayISO(),
      );

      // Customer details
      const customerName =
        existingBill.Customer?.name ||
        existingBill.customerName ||
        existingBill.name ||
        "";

      const customerPhone =
        existingBill.Customer?.phone ||
        existingBill.customerPhone ||
        existingBill.phone ||
        "";

      const customerUserId =
        existingBill.User?.id ||
        existingBill.userId ||
        customerInfo?.userId ||
        null;

      setCustomerInfo({
        name: existingBill.Customer?.name || customerName,
        phone: existingBill.Customer?.phone || customerPhone,
        userId: existingBill.userId || customerUserId,
      });

      // Loyalty points
      setLoyaltyPoints(
        existingBill.Customer?.loyalty_points ||
          existingBill.customerLoyaltyPoints ||
          0,
      );

      // Discount
      setGlobalDiscount(
        existingBill.global_discount_amount || existingBill.globalDiscount || 0,
      );

      // Items
      const items =
        existingBill.SalesItems ||
        existingBill.saleItems ||
        existingBill.items ||
        [];

      if (Array.isArray(items) && items.length > 0) {
        const mappedItems = items.map((item) => ({
          productId: String(item.productId || item.product_id || item.id || ""),

          productName: item.productName || item.product_name || item.name || "",

          price: parseFloat(
            item.ProductBatch?.salePrice ??
              item.price ??
              item.rate ??
              item.unitPrice ??
              0,
          ),

          // A saved line does not carry its price mode: use the product's saved one
          priceType: normalizePriceType(
            item.priceType ||
              findProduct(products, item.productId || item.product_id)
                ?.sellingPriceType,
          ),

          quantity: parseFloat(item.quantity || 1),

          taxRate: parseFloat(
            item.taxRate ||
              item.tax_rate ||
              item.gstPercentage ||
              item.taxPercentage ||
              0,
          ),

          discountPercent: parseFloat(
            item.discountPercent ||
              item.discount_percent ||
              item.discount ||
              item.discountPercentage ||
              0,
          ),

          unit: item.unit || "pcs",

          hsnCode: item.hsnCode || item.hsn_code || "",

          barcode: item.barcode || "",

          sku: item.sku || "",

          mrp: parseFloat(
            item.ProductBatch?.mrp ??
              item.ProductBatch?.MRP ??
              item.mrp ??
              item.Product?.MRP ??
              0,
          ),

          productBatchId: String(
            item.productBatchId || item.ProductBatch?.id || item.batchId || "",
          ),

          batchAvailableQuantity: item.ProductBatch?.availableQuantity,

          batchNumber:
            item.batchNumber ||
            item.batchNo ||
            item.ProductBatch?.batchNumber ||
            item.batch_number ||
            "",

          expiryDate: item.expiryDate || item.expiry_date || "",

          serialNumber: item.serialNumber || item.serial_number || "",

          notes: item.notes || "",
        }));

        addMultipleCartItemsDirect(mappedItems);
      }
    } else if (!editMode) {
      // Only initialize a completely new bill here
      if (!invoiceNo) {
        refreshInvoiceNo();
      }

      if (!saleDate) {
        setSaleDate(todayISO());
      }
    }

    // IMPORTANT:
    // Do NOT put saleBills in this dependency list.
  }, [editMode, billId]);

  // ── Fetch Users ──
  const loadUsers = useCallback(async () => {
    if (!shiftCompanyId) return;
    try {
      const data = await fetchCompanyUsersAPI(shiftCompanyId);
      setUsers(data.data || []);
    } catch {
      toastError("Failed to load user listing.");
    }
  }, [shiftCompanyId, toastError]);

  useEffect(() => {
    clearActiveShift();
    if (!billingUser?.id) return;

    setCustomerInfo((prev) => ({
      ...prev,
      userId: String(billingUser.id),
    }));
    loadUsers();
    checkCurrentShift(billingUser.id, shiftCompanyId).catch((err) => {
      toastError(typeof err === "string" ? err : "Failed to load active shift");
    });
  }, [
    billingUser?.id,
    shiftCompanyId,
    clearActiveShift,
    checkCurrentShift,
    loadUsers,
    setCustomerInfo,
    toastError,
  ]);

  useEffect(() => {
    loadHoldCarts();
    // Load held carts once when POS mounts; their behavior is independent of shifts.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e) {
      if (
        formDropdownRef.current &&
        !formDropdownRef.current.contains(e.target)
      ) {
        setAddItemDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const displayCart = applyPromotionPreviewPricing(pricedCart, promotionPreviews);
  const totals = calcBillTotals(displayCart, globalDiscount);
  const promotionPreviewLoading = Object.values(promotionPreviews).some(
    (preview) => preview.loading,
  );

  console.log("Computed totals:", totals);
  // Total item-level discount
  const itemDiscount = displayCart.reduce(
    (sum, item) => sum + (Number(item.discountAmount) || 0),
    0,
  );

  // Total discount (item discount + global discount)
  const totalDiscount = itemDiscount + (Number(globalDiscount) || 0);
  const grossMrp = displayCart.reduce(
    (sum, item) =>
      sum +
      (Number(item.mrp) || 0) *
        (isWeightProduct(item)
          ? normalizeWeightQuantity(
              item.quantity,
              item.quantityUnit || "KG",
            )
          : Number(item.quantity) || 0),
    0,
  );
  const matchedCustomer = customers.find(
    (customer) =>
      customerInfo.phone &&
      String(customer.phone || "").trim() === String(customerInfo.phone).trim(),
  );

  const actualTotal = Number(totals.grandTotal) || 0;

  const roundedTotal = Math.round(actualTotal);
  const returnCreditApplied = Math.min(
    Number(returnCredit?.remainingAmount) || 0,
    roundedTotal,
  );
  const payableTotal = Math.max(0, roundedTotal - returnCreditApplied);
  const openingFloatTotal = getDenominationTotal(openingDenominations);
  const closingCashTotal = getDenominationTotal(closingDenominations);
  const expectedClosingCash = getExpectedClosingCash(activeShift);
  const closingCashVariance = closingCashTotal - expectedClosingCash;
  const recordedShiftSales =
    Number(activeShift?.cashSalesTotal || 0) +
    Number(activeShift?.cardSalesTotal || 0) +
    Number(activeShift?.upiSalesTotal || 0) +
    Number(activeShift?.otherSalesTotal || 0);
  const averageRecordedTender = activeShift?.totalSalesCount
    ? recordedShiftSales / Number(activeShift.totalSalesCount)
    : 0;

  // const roundOff = Number((roundedTotal - actualTotal).toFixed(2));
 const roundOff = Number(totals.roundOff?.toFixed(2));
  /* ── Add Item Form Handlers ── */
  const handleAddItemSearchChange = (e) => {
    const val = e.target.value;

    setAddItemSearch(val);
    setAddItemProduct(null);
    setAddItemHighlightedIndex(-1);

    if (!val.trim()) {
      setAddItemSuggestions([]);
      setAddItemDropdownOpen(false);
      return;
    }

    const query = val.toLowerCase().trim();

    const matches = (products || [])
      .filter((p) => {
        return (
          (p.name && p.name.toLowerCase().includes(query)) ||
          (p.barcode && String(p.barcode).toLowerCase().includes(query)) ||
          (p.sku && String(p.sku).toLowerCase().includes(query)) ||
          (p.HSNCode && String(p.HSNCode).toLowerCase().includes(query))
        );
      })
      .slice(0, 15);

    setAddItemSuggestions(matches);
    setAddItemDropdownOpen(matches.length > 0);

    // Automatically highlight first product
    if (matches.length > 0) {
      setAddItemHighlightedIndex(0);
    }
  };

  const applyReturnCredit = useCallback(async (value) => {
    const code = String(value || '')
      .trim()
      .replace(/^RETURN-CREDIT:/i, '');
    if (!code) {
      toast.error('Return credit barcode is empty');
      return null;
    }
    if (editMode) {
      toast.error('Return credits can only be used on a new B2C sale');
      return null;
    }
    if (returnCredit && returnCredit.code !== code) {
      toast.error('Remove the current return credit before scanning another');
      return null;
    }

    setLoadingReturnCredit(true);
    try {
      const credit = await fetchSalesReturnCreditAPI(code);
      if (Number(credit.remainingAmount) <= 0) {
        throw new Error('This return credit has already been fully used');
      }
      setReturnCredit(credit);
      toast.success(`Return credit applied: ${formatCurrency(credit.remainingAmount)}`);
      return { name: `Return credit ${credit.code}` };
    } catch (error) {
      toast.error(error.message || 'Could not validate return credit');
      return null;
    } finally {
      setLoadingReturnCredit(false);
    }
  }, [editMode, returnCredit, toast.error, toast.success]);

  const addProductWithStockCheck = useCallback(
    (product) => {
      if (!product) return false;

      const productId = product.id || product._id;
      const remainingStock = getRemainingProductStock(cart, productId, product);
      const isWeight = isWeightProduct(product);
      const quantity = isWeight
        ? remainingStock === null
          ? 1
          : Math.min(1, Math.max(0, remainingStock))
        : 1;
      const quantityUnit = isWeight ? "KG" : "PCS";

      if (quantity <= 0 || (isWeight && quantity < 0.001)) {
        checkProductStock(product, 1, quantityUnit);
        return false;
      }
      if (!checkProductStock(product, quantity, quantityUnit)) return false;

      addToCart(product, quantity);
      toast.success(`Added ${product.name}`);
      return true;
    },
    [addToCart, cart, checkProductStock, toast],
  );

  /* Add a product straight into the current order, then get ready for the next scan */
  const addProductToOrder = (prod) => {
    if (!prod) return;
    if (!addProductWithStockCheck(prod)) return false;

    setAddItemSearch("");
    setAddItemProduct(null);
    setAddItemSuggestions([]);
    setAddItemDropdownOpen(false);
    setAddItemHighlightedIndex(-1);

    if (searchInputRef.current) searchInputRef.current.focus();
    return true;
  };

  const updateProductQuantity = (item, quantity) => {
    const product = findProduct(products, item.productId) || item;
    const quantityUnit =
      item.quantityUnit || (isWeightProduct(product) ? "KG" : "PCS");
    const currentQuantity = getQuantityInProductBaseUnit(
      item.quantity,
      quantityUnit,
      product,
    );
    const nextQuantity = getQuantityInProductBaseUnit(
      quantity,
      quantityUnit,
      product,
    );
    if (
      nextQuantity > currentQuantity + 0.000001 &&
      !checkProductStock(
        product,
        quantity,
        quantityUnit,
        item.cartLineId || item.productId,
      )
    ) {
      return false;
    }

    updateCartItem(item.cartLineId || item.productId, "quantity", quantity);
    return true;
  };

  const handleAddItemSearchKeyDown = (e) => {
    // Enter — works for barcode scanners (they type the code then press Enter)
    if (e.key === "Enter") {
      e.preventDefault();

      const typed = (e.currentTarget.value || "").trim();
      if (!typed) return;

      if (/^RETURN-CREDIT:/i.test(typed)) {
        setAddItemSearch("");
        setAddItemSuggestions([]);
        setAddItemDropdownOpen(false);
        void applyReturnCredit(typed);
        return;
      }

      const q = typed.toLowerCase();

      // 1) Exact barcode / SKU match always wins
      const exact = (products || []).find(
        (p) =>
          (p.barcode && String(p.barcode).trim().toLowerCase() === q) ||
          (p.sku && String(p.sku).trim().toLowerCase() === q),
      );
      if (exact) {
        if (priceCheckMode) {
          handlePriceCheckProduct(exact);
          return;
        }
        addProductToOrder(exact);
        return;
      }

      // 2) Otherwise use the highlighted suggestion (or the only suggestion)
      if (addItemSuggestions.length > 0) {
        const picked =
          addItemSuggestions[
            addItemHighlightedIndex >= 0 ? addItemHighlightedIndex : 0
          ];
        if (picked) {
            if (priceCheckMode) {
              handlePriceCheckProduct(picked);
              return;
            }
            addProductToOrder(picked);
            return;
          }
      }

      toast.error(`No product found for: "${typed}"`);
      return;
    }

    if (!addItemDropdownOpen || addItemSuggestions.length === 0) {
      return;
    }

    // Down Arrow
    if (e.key === "ArrowDown") {
      e.preventDefault();

      setAddItemHighlightedIndex((prev) => {
        if (prev < addItemSuggestions.length - 1) {
          return prev + 1;
        }

        return 0;
      });

      return;
    }

    // Up Arrow
    if (e.key === "ArrowUp") {
      e.preventDefault();

      setAddItemHighlightedIndex((prev) => {
        if (prev > 0) {
          return prev - 1;
        }

        return addItemSuggestions.length - 1;
      });

      return;
    }

    // Escape
    if (e.key === "Escape") {
      e.preventDefault();

      setAddItemDropdownOpen(false);
      setAddItemHighlightedIndex(-1);
    }
  };

  // Clicking a suggestion adds it to the current order directly
  const handleSelectFormProduct = (prod) => {
    if (priceCheckMode) {
      handlePriceCheckProduct(prod);
      return;
    }
    addProductToOrder(prod);
  };

  const handlePriceCheckProduct = (product) => {
    const salesPrice = getProductPricing(product, "sales").price;
    const mrp = Number(product.MRP ?? product.mrp) || 0;
    toast.success(
      `${product.name}: Selling ${formatCurrency(salesPrice)} · MRP ${formatCurrency(mrp)}`,
    );
    setPriceCheckMode(false);
    setAddItemSearch("");
    setAddItemSuggestions([]);
    setAddItemDropdownOpen(false);
    setAddItemHighlightedIndex(-1);
    searchInputRef.current?.focus();
  };

  /* ── Shift handlers ── */
  async function handleStartShift() {
    if (!billingUser?.id) {
      toast.error("An authenticated user is required to start a shift");
      return;
    }
    if (!areDenominationCountsValid(openingDenominations)) {
      toast.error("Enter a non-negative whole-number count for each denomination");
      return;
    }
    try {
      await startShift({
        userId: billingUser.id,
        companyId: shiftCompanyId,
        openingFloat: openingFloatTotal,
        openingDenominations: normalizeDenominationCounts(openingDenominations),
        terminalId: "POS-TERMINAL-1",
      });
      toast.success("Shift started ✓");
      setShiftModalOpen(false);
      setOpeningDenominations(createEmptyDenominationCounts());
    } catch (err) {
      toast.error(typeof err === "string" ? err : "Failed to start shift");
    }
  }

  function openShiftCloseModal() {
    setShiftCloseConfirmed(false);
    setClosingDenominations(createEmptyDenominationCounts());
    setShiftCloseModal(true);
  }

  async function handleEndShift() {
    if (
      !activeShift ||
      !shiftCloseConfirmed ||
      !areDenominationCountsValid(closingDenominations)
    ) return;
    try {
      const res = await endShift({
        shiftId: activeShift.id,
        closingCashActual: closingCashTotal,
        closingDenominations: normalizeDenominationCounts(closingDenominations),
      });
      toast.success(
        `Shift closed. Difference: ${formatCurrency(res?.data?.difference || 0)}`,
      );
      setShiftCloseModal(false);
      setClosingDenominations(createEmptyDenominationCounts());
    } catch (err) {
      toast.error(typeof err === "string" ? err : "Failed to close shift");
    }
  }

  /* ── Hold cart handler ── */
  async function handleHoldCart() {
    if (cart.length === 0) {
      toast.error("Cart is empty – nothing to hold");
      return;
    }
    try {
      await holdCartAction({
        userId: customerInfo.userId || null,
        customerName: customerInfo.name || "Walk-in Customer",
        customerPhone: customerInfo.phone || "",
        cartData: cart,
        totalAmount: totals.grandTotal,
        note: holdNote || "",
      });
      toast.success("Cart held successfully ✓");
      clearCart();
      setHoldNote("");
      refreshInvoiceNo();
    } catch (err) {
      toast.error(typeof err === "string" ? err : "Failed to hold cart");
    }
  }

  /* ── Resume held cart ── */
  async function handleResumeCart(id) {
    try {
      const res = await resumeHoldCart(id);
      const data = res?.data || res;

      console.log("RESUME DATA:", data);

      // Clear cart first
      clearCart();

      const items = Array.isArray(data.cartData)
        ? data.cartData
        : JSON.parse(data.cartData || "[]");

      if (items.length > 0) {
        addMultipleCartItemsDirect(items);
      }

      // Restore customer AFTER clearCart()
      setCustomerInfo({
        name: data.customerName || "",
        phone: data.customerPhone || "",
        userId: data.userId || "",
      });

      console.log("Customer restored:", {
        name: data.customerName,
        phone: data.customerPhone,
        userId: data.userId,
      });

      toast.success("Held cart restored ✓");
      setHoldDrawerOpen(false);
    } catch (err) {
      console.error("Resume cart error:", err);
      toast.error("Failed to resume cart");
    }
  }
  /* ── Add to cart handler (from scanner) ── */
  const handleAddProduct = useCallback(
    (product) => {
      addProductWithStockCheck(product);
    },
    [addProductWithStockCheck],
  );

  /* ── Barcode not found ── */
  const handleBarcodeNotFound = useCallback(
    (val) => {
      toast.error(`No product found for: "${val}"`);
    },
    [toast],
  );

  /* ── Camera scan result ── */
  const handleCameraScan = useCallback(
    (decodedText) => {
      if (/^RETURN-CREDIT:/i.test(decodedText.trim())) {
        void applyReturnCredit(decodedText);
        return { name: 'Return credit' };
      }

      const v = decodedText.trim().toLowerCase();
      const product =
        products.find((p) => p.barcode && p.barcode === decodedText) ||
        products.find((p) => p.sku && p.sku.toLowerCase() === v) ||
        products.find((p) => p.HSNCode && p.HSNCode.toLowerCase() === v) ||
        products.find((p) => p.name && p.name.toLowerCase() === v) ||
        null;

      if (product) {
        handleAddProduct(product);
      } else {
        toast.error(`No product found for: "${decodedText}"`);
      }
      return product;
    },
    [products, handleAddProduct, applyReturnCredit, toast],
  );

  /* Phone lookup for B2C */
  function handlePhoneChange(e) {
    const value = e.target.value;

    // BLOCK anything except digits
    if (value !== "" && !/^[0-9]+$/.test(value)) {
      return;
    }

    // BLOCK more than 10 digits
    if (value.length > 10) {
      return;
    }

    let existing = null;

    // Find customer when exactly 10 digits are entered
    if (value.length === 10) {
      existing = customers.find(
        (p) => String(p.phone || "").trim() === value.trim(),
      );
    }

    setCustomerInfo({
      ...customerInfo,
      phone: value,
      name: existing ? existing.name : customerInfo.name,
    });

    setLoyaltyPoints(existing?.loyalty_points || 0);
  }

  const handleCustomerNameChange = (e) => {
    const value = e.target.value;

    // Allow only alphabets and spaces
    if (!/^[A-Za-z\s]*$/.test(value)) {
      return;
    }

    setCustomerInfo({
      ...customerInfo,
      name: value,
    });
  };

  /* ── Save bill ── */
  async function handleSave(paymentDetails, receiptPaymentDetails) {
    if (cart.length === 0) {
      toast.error("Cart is empty");
      return;
    }

    const batchSelectionByProduct = new Map();
    for (const item of cart) {
      const key = String(item.productId);
      const selections = batchSelectionByProduct.get(key) || {
        count: 0,
        selected: 0,
      };
      selections.count += 1;
      if (item.productBatchId || item.batchId) selections.selected += 1;
      batchSelectionByProduct.set(key, selections);

      if (item.productBatchId || item.batchId) {
        const product = findProduct(products, item.productId) || item;
        const quantity = getQuantityInProductBaseUnit(
          item.quantity,
          item.quantityUnit || (isWeightProduct(product) ? "KG" : "PCS"),
          product,
        );
        const available = Number(item.batchAvailableQuantity);
        if (Number.isFinite(available) && quantity > available + 0.000001) {
          toast.error(
            `Only ${formatQuantity(available)} is available in the selected batch for ${item.productName}.`,
          );
          return;
        }
      }
    }

    if (
      [...batchSelectionByProduct.values()].some(
        ({ count, selected }) => selected > 0 && selected !== count,
      )
    ) {
      toast.error(
        "Select a batch for every line of a product, or clear all batch selections for that product.",
      );
      return;
    }

    const loggedInUserId = billingUser?.id;
    const loggedInCompanyId = shiftCompanyId;

    if (!customerInfo.name || !customerInfo.phone) {
      toast.error("Customer Details is Required!!");
      return;
    }

    if (!loggedInUserId) {
      toast.error("User Details is Required!!");
      return;
    }
    if (!loggedInCompanyId) {
      toast.error("Company Details is Required!!");
      return;
    }

    const finalCustomerInfo = {
      ...customerInfo,
      userId: loggedInUserId,
    };

    setSaving(true);

    try {
      const payload = buildSaleBillPayload({
        billForm: {
          invoiceNo,
          date: saleDate,
          items: displayCart,
          globalDiscount,
        },
        customerForm: finalCustomerInfo,
        validItems: displayCart,
        products,
      });
      const posBillItems = payload.items;

      const extraFields = {
        bill_type: "B2C",
        paymentStatus: "Paid",
        paymentMethod,
        shiftId: activeShift?.id || null,
        paymentDetails: paymentDetails || null,
        companyId: loggedInCompanyId || null,
        useProductSalesPrice: true,
        ...(!editMode && returnCredit && {
          returnCreditCode: returnCredit.code,
          returnCreditAmount: returnCreditApplied,
        }),
      };

      if (editMode && billId) {
        await updateBill(billId, {
          ...payload,
          items: posBillItems,
          ...extraFields,
        });
        if (loggedInUserId) {
          await checkCurrentShift(loggedInUserId, loggedInCompanyId).catch(() => {
            toast.warning("Invoice updated, but shift totals could not be refreshed.");
          });
        }

        toast.success("Invoice updated ✓");

        // Clear edited bill data from POS store
        clearCart();
        setReturnCredit(null);

        setCustomerInfo({
          name: "",
          phone: "",
          userId: loggedInUserId,
        });

        setLoyaltyPoints(0);
        setGlobalDiscount(0);
        setPaymentOpen(false);

        if (onSaved) {
          onSaved();
        } else if (onBack) {
          onBack();
        }

        return;
      } else {
        const created = await addBill({
          ...payload,
          items: posBillItems,
          ...extraFields,
        });
        if (loggedInUserId) {
          await checkCurrentShift(loggedInUserId, loggedInCompanyId).catch(() => {
            toast.warning("Invoice saved, but shift totals could not be refreshed.");
          });
        }

        toast.success("Invoice saved ✓");

        // The create call only returns a summary; fetch the saved invoice so the
        // receipt shows the backend-calculated taxable value / GST / totals.
        let savedBill = null;
        try {
          const savedId = created?.data?.id ?? created?.id;
          if (savedId) {
            const res = await fetchSaleBillByIdAPI(savedId);
            savedBill = res?.data ?? res ?? null;
          }
        } catch {
          savedBill = null;
        }
        // Stock changed on the server: drop cached batch lists so the next
        // scan shows the true remaining quantity per batch.
        invalidateBatchCache();
        const backendInvoiceNo =
          created?.data?.invoiceNumber ||
          created?.invoiceNumber ||
          savedBill?.invoiceNumber ||
          invoiceNo;
        const savedItems = savedBill?.SalesItems || savedBill?.items || [];
        const num = (v, fallback) =>
          v !== undefined && v !== null && !isNaN(Number(v))
            ? Number(v)
            : fallback;
        const receiptCreatedAt =
          savedBill?.createdAt ||
          savedBill?.created_at ||
          created?.data?.createdAt ||
          created?.data?.created_at ||
          created?.createdAt ||
          created?.created_at ||
          new Date().toISOString();
        const receiptSourceItems = savedItems.length ? savedItems : cart;
        const receiptItems = receiptSourceItems.map((sourceItem, i) => {
          const saved = savedItems.length ? sourceItem : null;
          const original = saved
            ? cart.find(
                (cartItem) =>
                  String(cartItem.productId) === String(saved.productId) &&
                  (!saved.productBatchId ||
                    String(cartItem.productBatchId) === String(saved.productBatchId)),
              )
            : sourceItem;
          const item = saved ? { ...original, ...saved } : sourceItem;
          return {
            ...item,

            productName:
              item.productName || item.name || item.Product?.name || "Item",

            quantity: Number(saved?.quantity ?? item.quantity) || 1,
            paidQuantity:
              saved?.paidQuantity ?? item.paidQuantity ?? item.quantity,
            freeQuantity: saved?.freeQuantity ?? item.freeQuantity ?? 0,
            totalQuantity:
              saved?.totalQuantity ??
              item.totalQuantity ??
              (Number(item.paidQuantity ?? item.quantity) +
                Number(item.freeQuantity || 0)),
            offerId: saved?.offerId ?? item.offerId,
            offerName: saved?.offerName ?? item.offerName,
            promotionName: saved?.promotionName ?? item.promotionName,
            itemRole: saved?.itemRole ?? item.itemRole,
            productBatchId:
              saved?.productBatchId ?? item.productBatchId,
            batchNumber:
              saved?.batchNumber ?? saved?.batchNo ?? item.batchNumber,
            quantityUnit: saved?.quantityUnit || item.quantityUnit,
            enteredQuantity: Number(saved?.quantity ?? item.quantity) || 1,
            enteredQuantityUnit: item.quantityUnit,

            price:
              (saved?.itemRole ?? item.itemRole) === "GIFT"
                ? Number(saved?.price) || 0
                : Number(item.price) || 0,
            mrp: Number(
              saved?.ProductBatch?.mrp ??
                saved?.ProductBatch?.MRP ??
                saved?.Product?.MRP ??
                item.mrp,
            ) || 0,

            // Backend-calculated line values when available (never re-taxed here)
            ...(saved && {
              afterDiscount: num(saved.baseRate, item.afterDiscount),
              taxAmount: num(saved.taxAmount, item.taxAmount),
              total: num(saved.netRate, item.total),
              taxRate: num(saved.taxPercentage, item.taxRate),
            }),

            netRate:
              Number(saved ? saved.netRate : item.total) ||
              Number(item.netRate) ||
              (Number(item.quantity) || 1) * (Number(item.price) || 0),
          };
        });
        const totalMrp = receiptItems.reduce(
          (sum, item) =>
            sum + (Number(item.mrp) || 0) * (Number(item.quantity) || 1),
          0,
        );
        const finalBillTotal = num(
          savedBill?.totalAmount,
          Number(totals.grandTotal) || 0,
        );
        const todaySavings = Math.max(0, totalMrp - finalBillTotal);

        const billForPrint = {
          bill_type: "B2C",
          invoiceNumber: backendInvoiceNo,
          invoiceNo: backendInvoiceNo,

          saleDate: savedBill?.saleDate || created?.data?.saleDate || saleDate,
          createdAt: receiptCreatedAt,

          items: receiptItems,

          customerName: finalCustomerInfo.name || "Walk-in Customer",

          customerPhone: finalCustomerInfo.phone || "",
          loyaltyPointsEarned: Number(created?.data?.loyaltyPointsEarned) || 0,
          loyaltyPointsBalance:
            created?.data?.loyaltyPointsBalance ??
            savedBill?.Customer?.loyalty_points ??
            null,

          paymentMethod,

          discountAmount: Number(globalDiscount) || 0,

          baseRate: num(savedBill?.baseRate, Number(totals.subtotal) || 0),

          tax: num(savedBill?.tax, Number(totals.totalTax) || 0),

          totalAmount: num(
            savedBill?.totalAmount,
            Number(totals.grandTotal) || 0,
          ),
          returnCreditAmount: Number(
            created?.data?.returnCredit?.appliedAmount ?? returnCreditApplied,
          ) || 0,
          amountReceived: Number(
            receiptPaymentDetails?.amountReceived ?? payableTotal,
          ),
          amountReturned: Number(receiptPaymentDetails?.amountReturned) || 0,
          todaySavings,

          User: {
            name:
              billingUser?.name ||
              activeShift?.user?.name ||
              "Store Manager",
          },

          ...extraFields,
        };

        // console.log("PRINT BILL:", billForPrint);

        setLastPrintedBill(billForPrint);
        setPaymentOpen(false);
        setPrintReady(true);

        clearCart();
        setReturnCredit(null);

        let newBillUserId = "";
        const storedAuthAfterSave = localStorage.getItem("thrive-auth-storage");

        if (storedAuthAfterSave) {
          try {
            const authData = JSON.parse(storedAuthAfterSave);
            newBillUserId = String(authData?.state?.user?.id || "");
          } catch (error) {
            console.error("Failed to read user:", error);
          }
        }

        setCustomerInfo({
          name: "",
          phone: "",
          userId: newBillUserId,
        });

        setLoyaltyPoints(0);
        setGlobalDiscount(0);

        refreshInvoiceNo();
        setSaleDate(todayISO());
      }
    } catch (err) {
      console.error(err);
      toast.error(
        "Failed to save invoice: " + (err.message || "Unknown error"),
      );
    } finally {
      setSaving(false);
    }
  }

  /* ── New bill / Void bill ── */
  function handleNewBill() {
    const storedAuth = localStorage.getItem("thrive-auth-storage");
    let loggedInUserId = "";

    if (storedAuth) {
      try {
        const authData = JSON.parse(storedAuth);
        loggedInUserId = String(authData?.state?.user?.id || "");
      } catch (error) {
        console.error("Failed to read user:", error);
      }
    }

    clearCart();
    setReturnCredit(null);

    setCustomerInfo({
      name: "",
      phone: "",
      userId: loggedInUserId,
    });

    setLoyaltyPoints(0);
    setGlobalDiscount(0);

    refreshInvoiceNo();
    setSaleDate(todayISO());
  }

  /* ── Keyboard shortcuts ── */
  useEffect(() => {
    function onKey(e) {
      if (e.key === "Escape") {
        e.preventDefault();
        if (paymentOpen) {
          setPaymentOpen(false);
          return;
        }
        if (cameraOpen) {
          setCameraOpen(false);
          return;
        }
        if (holdDrawerOpen) {
          setHoldDrawerOpen(false);
          return;
        }
        if (shiftModalOpen) {
          setShiftModalOpen(false);
          return;
        }
        if (shiftCloseModal) {
          setShiftCloseModal(false);
          return;
        }
        if (addItemDropdownOpen) {
          setAddItemDropdownOpen(false);
          setAddItemHighlightedIndex(-1);
          return;
        }

        const target = e.target;
        const isEditing =
          target instanceof HTMLElement &&
          (target.isContentEditable ||
            target.matches("input, textarea, select"));
        if (!isEditing) onBack?.();
        return;
      }

      if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
      if (
        paymentOpen ||
        cameraOpen ||
        holdDrawerOpen ||
        shiftModalOpen ||
        shiftCloseModal
      ) {
        return;
      }

      if (e.key === "F2") {
        e.preventDefault();
        searchInputRef.current?.focus();
      } else if (e.key === "F3") {
        e.preventDefault();
        setPriceCheckMode((current) => !current);
        searchInputRef.current?.focus();
      } else if (e.key === "F4") {
        e.preventDefault();
        customerPhoneInputRef.current?.focus();
      } else if (e.key === "F5") {
        e.preventDefault();
        cartTableRef.current?.querySelector(".pos-exact-qty-input")?.focus();
      } else if (e.key === "F6") {
        e.preventDefault();
        customerNameInputRef.current?.focus();
      } else if (e.key === "F8") {
        e.preventDefault();
        if (cart.length > 0) setPaymentOpen(true);
      } else if (e.key === "F9") {
        e.preventDefault();
        if (
          cart.length === 0 ||
          window.confirm("Start a new bill and clear the current cart?")
        ) {
          handleNewBill();
        }
      } else if (e.key === "F10") {
        e.preventDefault();
        if (cart.length > 0) {
          handleHoldCart();
        } else {
          setHoldDrawerOpen(true);
        }
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [
    cart,
    paymentOpen,
    cameraOpen,
    holdDrawerOpen,
    shiftModalOpen,
    shiftCloseModal,
    addItemDropdownOpen,
    onBack,
  ]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!printReady || !lastPrintedBill) return;

    const timer = setTimeout(() => {
      // console.log("Printing bill:", lastPrintedBill);

      const thermal = document.getElementById("thermal-bill-print");

      // console.log("Thermal element:", thermal);

      if (!thermal) {
        console.error("Thermal invoice element not found");
        return;
      }

      document.body.classList.add("printing-thermal-receipt");

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          window.print();
        });
      });
    }, 500);

    const afterPrint = () => {
      document.body.classList.remove("printing-thermal-receipt");

      setPrintReady(false);
      setLastPrintedBill(null);
    };

    window.addEventListener("afterprint", afterPrint);

    return () => {
      clearTimeout(timer);

      window.removeEventListener("afterprint", afterPrint);

      document.body.classList.remove("printing-thermal-receipt");
    };
  }, [printReady, lastPrintedBill]);

  const formattedDateTimeStr = new Date().toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <>
      {/* ── Thermal Bill (print-only) ── */}
      {lastPrintedBill && (
        <ThermalInvoice
          bill={lastPrintedBill}
          companies={companyForReceipt}
          party={{
            name: lastPrintedBill.customerName || "Walk-in Customer",
            phone: lastPrintedBill.customerPhone || "",
          }}
          items={lastPrintedBill.items || []}
          invoiceLabel="INVOICE"
          partyLabel="Customer"
          printRef={printRef}
          showActionBar={false}
          showBatch={false}
        />
      )}

      <div className="pos-b2c-root billflow-pos-terminal">
        <ToastContainer toasts={toast.toasts} />

        {/* ── Camera Scanner Modal ── */}
        <CameraScanner
          open={cameraOpen}
          onClose={() => setCameraOpen(false)}
          onScan={handleCameraScan}
        />

        {/* ── Payment Modal ── */}
        <POSPaymentModal
          open={paymentOpen}
          totals={{
            ...totals,
            grandTotal: payableTotal,
            preCreditGrandTotal: roundedTotal,
            roundOff: roundOff,
            returnCreditAmount: returnCreditApplied,
          }}
          paymentMethod={paymentMethod}
          onPaymentMethodChange={setPaymentMethod}
          customerInfo={customerInfo}
          onCustomerChange={setCustomerInfo}
          invoiceNo={invoiceNo}
          saleDate={saleDate}
          activeShift={activeShift}
          cashier={billingUser}
          loyaltyPoints={loyaltyPoints}
          printerWidth={printerWidth}
          autoPrint={autoPrint}
          totalDiscount={totalDiscount}
          itemDiscount={itemDiscount}
          globalDiscount={globalDiscount}
          onConfirm={handleSave}
          onClose={() => setPaymentOpen(false)}
          saving={saving}
        />

        {/* ═══ TOP NAVBAR ═══ */}
        <div className="pos-exact-topbar">
          <div className="pos-exact-topbar__search">
            {onBack && (
              <button
                className="pos-exact-back-btn"
                onClick={() => {
                  onBack();
                  setCustomerInfo({
                    name: "",
                    phone: "",
                    userId: "",
                  });
                  setLoyaltyPoints(0);
                  clearCart();
                  setReturnCredit(null);
                }}
                title="Back (Esc)"
              >
                ‹ Back
              </button>
            )}
            <span className="pos-terminal-scanner-badge">
              <span
                className={`pos-terminal-status-dot ${
                  scannerEnabled ? "is-ready" : ""
                }`}
              />
              EAN-13 {scannerEnabled ? "READY" : "OFF"}
            </span>
            <div className="pos-exact-search-wrap">
              <FiSearch className="pos-exact-search-icon" />
              <input
                type="text"
                placeholder={
                  priceCheckMode
                    ? "Price check: scan barcode or search product, then press Enter..."
                    : "Scan barcode or search product by name / SKU, then press Enter..."
                }
                className="pos-exact-search-input"
                ref={searchInputRef}
                autoFocus
                role="combobox"
                aria-label="Scan barcode or search products"
                aria-autocomplete="list"
                aria-expanded={addItemDropdownOpen && addItemSuggestions.length > 0}
                aria-controls="pos-product-suggestions"
                aria-activedescendant={
                  addItemHighlightedIndex >= 0
                    ? `pos-product-suggestion-${addItemHighlightedIndex}`
                    : undefined
                }
                value={addItemSearch}
                onChange={handleAddItemSearchChange}
                onKeyDown={handleAddItemSearchKeyDown}
                onFocus={() => {
                  if (addItemSuggestions.length > 0) {
                    setAddItemDropdownOpen(true);

                    if (addItemHighlightedIndex === -1) {
                      setAddItemHighlightedIndex(0);
                    }
                  }
                }}
              />
              {addItemDropdownOpen && addItemSuggestions.length > 0 && (
                <div
                  className="pos-exact-dropdown"
                  id="pos-product-suggestions"
                  role="listbox"
                  ref={formDropdownRef}
                >
                  {addItemSuggestions.map((item, index) => (
                    <div
                      key={item.id || item._id}
                      id={`pos-product-suggestion-${index}`}
                      className={`pos-exact-dropdown-item ${
                        index === addItemHighlightedIndex
                          ? "pos-exact-dropdown-item--highlighted"
                          : ""
                      }`}
                      role="option"
                      aria-selected={index === addItemHighlightedIndex}
                      onMouseEnter={() => setAddItemHighlightedIndex(index)}
                      onClick={() => handleSelectFormProduct(item)}
                    >
                      <span className="pos-exact-dropdown-name">
                        {item.name}
                      </span>

                      <span style={{ textAlign: "right" }}>
                        <span className="pos-exact-dropdown-price">
                          {formatCurrency(item.salesPrice || item.price || 0)}
                        </span>
                        {getProductStockLabel(item) && (
                          <span
                            className="pos-exact-item-sub"
                            style={{ display: "block" }}
                          >
                            Total stock: {getProductStockLabel(item)}
                          </span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button
              className="pos-exact-scan-btn"
              onClick={() => setCameraOpen(true)}
              title="Scan Barcode with Camera"
            >
              <span className="scan-icon-box">📷</span>
              <span>Scan</span>
            </button>
            <button
              type="button"
              className={`pos-terminal-price-check ${priceCheckMode ? "is-active" : ""}`}
              onClick={() => {
                setPriceCheckMode((current) => !current);
                searchInputRef.current?.focus();
              }}
              aria-pressed={priceCheckMode}
              title="Toggle product price check (F3)"
            >
              {priceCheckMode ? "Exit Price Check" : "Price Check"} <kbd>F3</kbd>
            </button>
          </div>

          <div className="pos-exact-topbar__meta">
            <span className="pos-exact-inv-badge">
              {invoiceNo || "INV-2024-001"}
            </span>
            <div className="pos-terminal-meta-block">
              <span className="pos-terminal-meta-label">DATE / TIME</span>
              <strong>
                {saleDate || formattedDateTimeStr} ·{" "}
                {new Date().toLocaleTimeString("en-IN", {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </strong>
            </div>
            <div className="pos-terminal-meta-block">
              <span className="pos-terminal-meta-label">LANE</span>
              <strong>01</strong>
            </div>

            {/* ── Shift Button ── */}
            <button
              className={`pos-exact-topbar-btn pos-exact-topbar-btn--shift ${activeShift ? "active" : ""}`}
              onClick={() =>
                activeShift
                  ? openShiftCloseModal()
                  : setShiftModalOpen(true)
              }
              title={
                activeShift
                  ? `Shift #${activeShift.id} Active — Click to Close`
                  : "Start New Shift"
              }
            >
              <FiClock />
              <span>
                {activeShift ? `Shift #${activeShift.id}` : "Start Shift"}
              </span>
              {activeShift && (
                <span className="pos-exact-topbar-dot pos-exact-topbar-dot--green" />
              )}
            </button>

            {/* ── Hold Bill Button ── */}
            <button
              className="pos-exact-topbar-btn pos-exact-topbar-btn--hold"
              onClick={() => {
                if (cart.length > 0) {
                  handleHoldCart();
                } else {
                  setHoldDrawerOpen(true);
                }
              }}
              title={
                cart.length > 0 ? "Hold Current Bill (F10)" : "View Held Bills"
              }
            >
              <FiLayers />
              <span>{cart.length > 0 ? "Hold Bill" : "Held Bills"}</span>
              {holdCarts.length > 0 && (
                <span className="pos-exact-topbar-badge">
                  {holdCarts.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* ═══ MAIN LAYOUT GRID ═══ */}
        <div className="pos-exact-container">
          {/* LEFT COLUMN: Customer + Add Item + Cart Table */}
          <div className="pos-exact-left-col">
            {/* Top Row: Two Cards */}
            <div className="pos-exact-cards-row">
              {/* Card 1: Customer Details */}
              <div className="pos-exact-card pos-exact-card--customer">
                <div className="pos-exact-card__title">
                  <FiUser className="pos-exact-card__icon" />
                  <span>Customer Details</span>
                </div>
                <div className="pos-exact-card__body pos-customer-terminal-fields">
                  <div className="pos-exact-form-group">
                    <label>
                      Phone Number <span style={{ color: "red" }}>*</span>
                    </label>
                    <div className="pos-exact-input-icon-wrap">
                      <span className="pos-customer-country-code">+91</span>
                      <input
                        type="tel"
                        name="phone"
                        className="pos-exact-input pos-cust-phone-input"
                        ref={customerPhoneInputRef}
                        placeholder="Enter phone number"
                        value={customerInfo.phone || ""}
                        onChange={handlePhoneChange}
                        maxLength={10}
                        inputMode="numeric"
                        autoComplete="tel"
                      />
                    </div>
                  </div>
                  <div className="pos-exact-form-group">
                    <label>
                      Customer Name <span style={{ color: "red" }}>*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      className="pos-exact-input"
                      ref={customerNameInputRef}
                      value={customerInfo.name}
                      onChange={handleCustomerNameChange}
                      placeholder="Enter customer name"
                    />
                  </div>
                  {/* ── Loyalty Points ── */}
                  <div className="pos-exact-loyalty-row">
                    <FiStar className="pos-exact-loyalty-icon" />
                    <span className="pos-exact-loyalty-label">
                      {matchedCustomer ? "LOYALTY MEMBER" : "LOYALTY POINTS"}
                    </span>
                    <span className="pos-exact-loyalty-value">
                      {loyaltyPoints || 0}
                    </span>
                    <span className="pos-customer-tier">
                      {matchedCustomer?.loyaltyTier ||
                        (loyaltyPoints > 0 ? "MEMBER" : "GUEST")}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Row: Current Order Table */}
            <div className="pos-exact-card pos-exact-card--order">
              <div className="pos-exact-card__header">
                <div className="pos-exact-card__title">
                  <FiFileText className="pos-exact-card__icon" />
                  <span>Current Order</span>
                </div>
                <span className="pos-exact-item-count-badge">
                  {cart.length} Items
                </span>
              </div>
              <div
                className="pos-exact-item-sub"
                style={{ padding: "0 16px 10px" }}
              >
                Promotional free quantities are checked by the backend at checkout
                and shown on the saved invoice.
              </div>

              <div className="pos-exact-table-wrap" ref={cartTableRef}>
                <table className="pos-exact-table">
                  <thead>
                    <tr>
                      <th style={{ width: 40, textAlign: "center" }}>#</th>
                      <th>Item Description & Brand</th>
                      <th style={{ width: 130 }}>SKU / EAN</th>
                      <th style={{ width: 80, textAlign: "center" }}>Qty</th>
                      <th style={{ width: 100, textAlign: "right" }}>Rate</th>
                      <th style={{ width: 90, textAlign: "right" }}>MRP</th>
                      <th style={{ width: 100, textAlign: "right" }}>
                        Discount %
                      </th>
                      <th style={{ width: 90, textAlign: "right" }}>GST</th>
                      <th style={{ width: 110, textAlign: "right" }}>Amount</th>
                      <th style={{ width: 60, textAlign: "center" }}>Act</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cart.length === 0 ? (
                      <tr>
                        <td colSpan="10">
                          <div className="pos-exact-empty-cart">
                            <div className="pos-exact-empty-icon">🛒</div>
                            <div className="pos-exact-empty-title">
                              No Items in Order
                            </div>
                            <div className="pos-exact-empty-sub">
                              Scan a barcode or search in the top bar and press
                              Enter to add products to this sale
                            </div>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      displayCart.map((item, idx) => {
                        const displayItem = item;
                        const productStock = findProduct(products, item.productId);
                        const totalStockLabel = getProductStockLabel(productStock);
                        const lineTotal = Number(displayItem.total) || 0;
                        const isFirstProductLine = cart.findIndex(
                          (candidate) =>
                            String(candidate.productId) === String(item.productId),
                        ) === idx;
                        const promotionPreview = isFirstProductLine
                          ? promotionPreviews[String(item.productId)]
                          : null;
                        const previewData = promotionPreview?.data;
                        const currentProductQuantity = cart
                          .filter(
                            (line) =>
                              String(line.productId) === String(item.productId),
                          )
                          .reduce(
                            (total, line) =>
                              total +
                              (isWeightProduct(line)
                                ? normalizeWeightQuantity(
                                    line.quantity,
                                    line.quantityUnit || "KG",
                                  )
                                : Number(line.quantity) || 0),
                            0,
                          );
                        const previewPaidQuantity = Number(
                          previewData?.product?.paidQuantity ??
                            previewData?.pricing?.paidQuantity,
                        );
                        const previewMatchesCart =
                          Number.isFinite(previewPaidQuantity) &&
                          Math.abs(previewPaidQuantity - currentProductQuantity) <=
                            0.0005;
                        const previewPromotion = previewMatchesCart
                          ? previewData?.promotion
                          : null;
                        const storedFreeQuantity = Number(item.freeQuantity) || 0;
                        const previewFreeQuantity = Number(
                          previewMatchesCart
                            ? previewData?.pricing?.freeQuantity ??
                                previewData?.product?.freeQuantity ??
                                previewPromotion?.freeQuantity ??
                                0
                            : 0,
                        );
                        const giftProductId =
                          previewPromotion?.giftProductId ??
                          previewPromotion?.giftProduct?.id;
                        const hasDifferentProductGift =
                          giftProductId != null &&
                          String(giftProductId) !== String(item.productId);
                        const freeQuantityForDisplay =
                          item.itemRole !== "GIFT" && storedFreeQuantity > 0
                            ? storedFreeQuantity
                            : item.itemRole !== "GIFT" &&
                                isFirstProductLine &&
                                !hasDifferentProductGift
                              ? previewFreeQuantity
                              : 0;
                        const isWeightLine = isWeightProduct(item);
                        const unitMultiplier =
                          isWeightLine && item.quantityUnit === "GRAM" ? 1000 : 1;
                        const paidQuantityForDisplay =
                          storedFreeQuantity > 0
                            ? Number(
                                item.paidQuantity ??
                                  Math.max(0, Number(item.quantity) - storedFreeQuantity),
                              )
                            : isFirstProductLine && previewFreeQuantity > 0
                              ? cart
                                  .filter(
                                    (line) =>
                                      String(line.productId) === String(item.productId),
                                  )
                                  .reduce(
                                    (total, line) =>
                                      total +
                                      (isWeightLine
                                        ? normalizeWeightQuantity(
                                            line.quantity,
                                            line.quantityUnit || "KG",
                                          )
                                        : Number(line.quantity) || 0),
                                    0,
                                  ) * unitMultiplier
                              : Number(item.quantity) || 0;
                        const totalQuantity = Number(
                          item.totalQuantity ?? item.quantity,
                        );
                        const paidOnlyAmount =
                          storedFreeQuantity > 0 && totalQuantity > 0
                            ? (lineTotal *
                                (Number(item.paidQuantity) ||
                                  Math.max(0, totalQuantity - storedFreeQuantity))) /
                              totalQuantity
                            : lineTotal;
                        const itemTotal = paidOnlyAmount;
                        const rate = Number(item.price) || 0;
                        const selectedBatchId = String(
                          item.productBatchId || item.batchId || "",
                        );
                        const excludedBatchIds = cart
                          .filter(
                            (line) =>
                              String(line.productId) === String(item.productId) &&
                              String(line.cartLineId || line.productId) !==
                                String(item.cartLineId || item.productId),
                          )
                          .map((line) => line.productBatchId || line.batchId)
                          .filter(Boolean)
                          .map(String);
                        const requestedBatchQuantity = getQuantityInProductBaseUnit(
                          item.quantity,
                          item.quantityUnit ||
                            (isWeightProduct(productStock) ? "KG" : "PCS"),
                          productStock || item,
                        );

                        return (
                          <tr key={item.cartLineId || item.productId || idx}>
                            <td
                              style={{
                                textAlign: "center",
                                color: "#64748b",
                                fontWeight: 600,
                              }}
                            >
                              {idx + 1}
                            </td>
                            <td className="pos-ledger-description">
                              <div className="pos-exact-item-name">
                                {item.productName}
                              </div>
                              {(productStock?.brand?.name ||
                                brands.find(
                                  (brand) =>
                                    String(brand.id || brand._id) ===
                                    String(productStock?.brandId || item.brandId),
                                )?.name ||
                                item.brandName) && (
                                <div className="pos-ledger-meta">
                                  Brand: {productStock?.brand?.name ||
                                    brands.find(
                                      (brand) =>
                                        String(brand.id || brand._id) ===
                                        String(productStock?.brandId || item.brandId),
                                    )?.name ||
                                    item.brandName}
                                </div>
                              )}
                              {item.batchNumber && (
                                <div className="pos-ledger-meta">
                                  Batch: {item.batchNumber}
                                </div>
                              )}
                              {item.hsnCode && (
                                <div className="pos-ledger-meta">
                                  HSN: {item.hsnCode}
                                </div>
                              )}
                              {totalStockLabel && (
                                <div className="pos-exact-item-sub">
                                  Total product stock: {totalStockLabel}
                                </div>
                              )}
                              {productStock && (
                                <div style={{ marginTop: 6, maxWidth: 320 }}>
                                  <BatchSelector
                                    productId={item.productId}
                                    side="sales"
                                    value={selectedBatchId}
                                    excludeIds={excludedBatchIds}
                                    requestedQuantity={
                                      editMode ? undefined : requestedBatchQuantity
                                    }
                                    allowUnbatchedStock
                                    allowUnavailableSelection={editMode}
                                    onSelect={(batch) => {
                                      const savedPricing = getProductPricing(
                                        productStock,
                                        "sales",
                                      );
                                      const batchId = batch
                                        ? String(batch.id || batch._id)
                                        : "";
                                      updateCartItem(
                                        item.cartLineId || item.productId,
                                        {
                                          productBatchId: batchId,
                                          batchId,
                                          batchNumber:
                                            batch?.batchNumber ||
                                            batch?.batchNo ||
                                            "",
                                          batchNo:
                                            batch?.batchNo ||
                                            batch?.batchNumber ||
                                            "",
                                          batchAvailableQuantity: batch
                                            ? Number(
                                                batch.availableQuantity ??
                                                  batch.quantity ??
                                                  0,
                                              )
                                            : undefined,
                                          expiryDate: batch?.expiryDate || "",
                                          price: Number(
                                            batch?.salePrice ??
                                              batch?.sellingPrice ??
                                              savedPricing.price,
                                          ),
                                          mrp: Number(
                                            batch?.mrp ??
                                              batch?.MRP ??
                                              productStock.MRP ??
                                              productStock.mrp ??
                                              0,
                                          ),
                                          discountPercent: 0,
                                          priceType: savedPricing.priceType,
                                          taxRate: Number(productStock.taxRate) || 0,
                                        },
                                      );
                                    }}
                                  />
                                </div>
                              )}
                              {promotionPreview?.loading && isFirstProductLine && (
                                <div className="pos-promotion-preview is-loading">Checking offers…</div>
                              )}
                              {promotionPreview?.error && isFirstProductLine && (
                                <div className="pos-promotion-preview is-warning" role="status">
                                  Promotion preview failed: {promotionPreview.error}
                                </div>
                              )}
                              {previewPromotion && isFirstProductLine && (
                                <div className="pos-promotion-preview">
                                  <strong>{previewPromotion.name}</strong>
                                  {(Number(previewPromotion.discountPercentage) > 0 || Number(previewPromotion.discountAmount) > 0) && (
                                    <span>
                                      Discount{' '}
                                      {Number(previewPromotion.discountPercentage) > 0
                                        ? `${Number(previewPromotion.discountPercentage)}%`
                                        : formatCurrency(previewPromotion.discountAmount)}
                                    </span>
                                  )}
                                  {previewPromotion.giftProduct?.name && (
                                    <span>FREE GIFT: {previewPromotion.giftProduct.name}</span>
                                  )}
                                  {previewData.pricing?.payableAmount !== undefined && (
                                    <span>
                                      Offer total: {formatCurrency(previewData.pricing.payableAmount)}
                                    </span>
                                  )}
                                  <small>Final offer and amount are rechecked at checkout.</small>
                                </div>
                              )}
                            </td>
                            <td className="pos-ledger-code">
                              {item.barcode ||
                                item.SKU ||
                                item.sku ||
                                productStock?.barcode ||
                                productStock?.SKU ||
                                productStock?.sku ||
                                "—"}
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <div className="pos-exact-qty-controls">
                                <button
                                  className="pos-exact-qty-btn"
                                  aria-label={`Decrease ${item.productName} quantity`}
                                  onClick={() =>
                                    updateProductQuantity(
                                      item,
                                      isWeightProduct(item)
                                        ? Math.max(
                                            item.quantityUnit === "GRAM" ? 1 : 0.001,
                                            Number(
                                              (
                                                item.quantity -
                                                (item.quantityUnit === "GRAM"
                                                  ? 1
                                                  : 0.001)
                                              ).toFixed(3),
                                            ),
                                          )
                                        : Math.max(1, item.quantity - 1),
                                    )
                                  }
                                >
                                  −
                                </button>
                                <POSQtyInput
                                  value={item.quantity}
                                  ariaLabel={`Quantity for ${item.productName}`}
                                  step={
                                    isWeightProduct(item) &&
                                    item.quantityUnit !== "GRAM"
                                      ? 0.001
                                      : 1
                                  }
                                  allowDecimal={
                                    isWeightProduct(item) &&
                                    item.quantityUnit !== "GRAM"
                                  }
                                  onCommit={(n) =>
                                    updateProductQuantity(
                                      item,
                                      isWeightProduct(item)
                                        ? Math.max(
                                            item.quantityUnit === "GRAM"
                                              ? 1
                                              : 0.001,
                                            n,
                                          )
                                        : Math.max(1, Math.round(n)),
                                    )
                                  }
                                  onEnter={() => {
                                    if (searchInputRef.current)
                                      searchInputRef.current.focus();
                                  }}
                                />
                                <button
                                  className="pos-exact-qty-btn"
                                  aria-label={`Increase ${item.productName} quantity`}
                                  onClick={() =>
                                    updateProductQuantity(
                                      item,
                                      item.quantity +
                                        (isWeightProduct(item) &&
                                        item.quantityUnit !== "GRAM"
                                          ? 0.001
                                          : 1),
                                    )
                                  }
                                >
                                  +
                                </button>
                              </div>
                              {freeQuantityForDisplay > 0 && (
                                <div
                                  className="pos-exact-item-sub"
                                  style={{ fontWeight: 700, textAlign: "center" }}
                                >
                                  {formatQuantity(paidQuantityForDisplay)}+
                                  {formatQuantity(freeQuantityForDisplay * unitMultiplier)}
                                </div>
                              )}
                              {isWeightProduct(item) && (
                                <select
                                  className="form-select"
                                  aria-label={`Quantity unit for ${item.productName}`}
                                  value={item.quantityUnit || "KG"}
                                  onChange={(event) => {
                                    const nextUnit = event.target.value;
                                    const baseQuantity = normalizeWeightQuantity(
                                      item.quantity,
                                      item.quantityUnit || "KG",
                                    );
                                    updateCartItem(item.cartLineId || item.productId, {
                                      quantityUnit: nextUnit,
                                      quantity:
                                        nextUnit === "GRAM"
                                          ? Number((baseQuantity * 1000).toFixed(3))
                                          : Number(baseQuantity.toFixed(3)),
                                    });
                                  }}
                                  style={{ marginTop: 4, minWidth: 72 }}
                                >
                                  <option value="GRAM">GRAM</option>
                                  <option value="KG">KG</option>
                                </select>
                              )}
                            </td>
                            <td
                              style={{
                                textAlign: "right",
                                fontWeight: 600,
                                color: "#334155",
                              }}
                            >
                              {formatCurrency(rate)}
                              {isWeightProduct(item) ? " / KG" : ""}
                            </td>
                            <td className="pos-ledger-mrp">
                              {formatCurrency(
                                item.mrp ??
                                  item.MRP ??
                                  productStock?.MRP ??
                                  productStock?.mrp ??
                                  0,
                              )}
                            </td>
                            <td
                              style={{
                                textAlign: "right",
                              }}
                            >
                              <POSDiscountInput
                                value={item.discountPercent}
                                aria-label={`Discount percentage for ${item.productName}`}
                              />
                              {item.discountAmount > 0 && (
                                <div className="pos-exact-discount-amount">
                                  −{formatCurrency(item.discountAmount)}
                                </div>
                              )}
                            </td>
                            <td style={{ textAlign: "right" }}>
                              <div>{Number(item.taxRate) || 0}%</div>
                              <div className="pos-exact-gst-amount">
                                {formatCurrency(item.taxAmount || 0)}
                              </div>
                            </td>
                            <td
                              style={{
                                textAlign: "right",
                                fontWeight: 800,
                                color: "#0f172a",
                              }}
                            >
                              {formatCurrency(itemTotal)}
                            </td>
                            <td style={{ textAlign: "center" }}>
                              <button
                                className="pos-exact-remove-btn"
                                onClick={() => removeFromCart(item.cartLineId || item.productId)}
                                title="Remove item"
                                aria-label={`Remove ${item.productName}`}
                              >
                                <FiTrash2 />
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Sidebar (User + Shift + Hold/Void + Totals) */}
          <div className="pos-exact-right-col">
            {/* Store User & Shift Card */}
            <div className="pos-exact-user-card">
              <div className="pos-exact-user-avatar">
                <FiUser />
              </div>
              <div className="pos-exact-user-info">
                <div className="pos-exact-user-name">
                  {activeShift?.user?.name || "Store Manager"}
                </div>
                <div className="pos-terminal-user-meta">
                  CASHIER #{activeShift?.userId || billingUser?.id || "—"} ·
                  {" "}{activeShift?.terminalId || "POS-TERMINAL-1"}
                </div>
                <div
                  className="pos-exact-user-shift"
                  onClick={() =>
                    activeShift
                      ? openShiftCloseModal()
                      : setShiftModalOpen(true)
                  }
                  title="Click to manage shift"
                >
                  <span className="pos-exact-shift-dot"></span>
                  <span>
                    {activeShift
                      ? `Active Shift (#${activeShift.id})`
                      : "Start Shift"}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions: Hold Sale & Void Sale */}
            <div className="pos-exact-sidebar-actions">
              <button
                className="pos-exact-sidebar-btn pos-exact-sidebar-btn--hold"
                onClick={handleHoldCart}
                disabled={cart.length === 0}
              >
                <FiPauseCircle />
                <span>Hold Sale</span>
              </button>

              <button
                className="pos-exact-sidebar-btn pos-exact-sidebar-btn--void"
                onClick={handleNewBill}
              >
                <FiXCircle />
                <span>Void Sale</span>
              </button>
            </div>

            {/* Totals & Payment Section */}
            <div className="pos-exact-totals-box">
              {returnCredit && (
                <div
                  className="pos-exact-summary-row"
                  style={{ color: "#15803d", alignItems: "flex-start" }}
                >
                  <span>
                    Return credit
                    <span style={{ display: "block", fontSize: 11, color: "#64748b" }}>
                      {returnCredit.code}
                      {Number(returnCredit.remainingAmount) > returnCreditApplied &&
                        ` · ${formatCurrency(Number(returnCredit.remainingAmount) - returnCreditApplied)} remains`}
                    </span>
                  </span>
                  <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    −{formatCurrency(returnCreditApplied)}
                    <button
                      type="button"
                      className="btn btn--ghost btn--sm"
                      onClick={() => setReturnCredit(null)}
                      disabled={loadingReturnCredit}
                      aria-label="Remove return credit"
                    >
                      Remove
                    </button>
                  </span>
                </div>
              )}
              {/* Total Discount */}
              <div className="pos-exact-summary-row">
                <span>Gross MRP</span>
                <span className="pos-exact-summary-val">
                  {formatCurrency(grossMrp)}
                </span>
              </div>

              {itemDiscount > 0 && (
                <div className="pos-exact-summary-row pos-exact-summary-row--savings">
                  <span>Item Price Savings</span>
                  <span className="pos-exact-summary-val">
                    −{formatCurrency(itemDiscount)}
                  </span>
                </div>
              )}

              <div className="pos-exact-summary-row">
                <span>Subtotal</span>
                <span className="pos-exact-summary-val">
                  {formatCurrency(totals.subtotal)}
                </span>
              </div>

              <div className="pos-exact-summary-row">
                <span>GST Total</span>
                <span className="pos-exact-summary-val">
                  {formatCurrency(totals.totalTax)}
                </span>
              </div>

              {/* Round Off */}
              <div className="pos-exact-summary-row">
                <span>Round Off</span>
                <span>
                  {roundOff > 0 ? "+" : ""}
                  {formatCurrency(roundOff)}
                </span>
              </div>

              {globalDiscount > 0 && (
                <div
                  className="pos-exact-summary-row"
                  style={{ color: "#ef4444" }}
                >
                  <span>Bill / Coupon Discount</span>
                  <span className="pos-exact-summary-val">
                    −{formatCurrency(globalDiscount)}
                  </span>
                </div>
              )}

              {totalDiscount > 0 && (
                <div className="pos-terminal-savings-row">
                  <span>TOTAL BILL SAVINGS</span>
                  <strong>{formatCurrency(totalDiscount)}</strong>
                </div>
              )}

              <div className="pos-exact-grand-total">
                <span className="pos-exact-gt-label">
                  {returnCreditApplied > 0 ? "AMOUNT DUE" : "GRAND TOTAL"}
                </span>
                <span className="pos-exact-gt-val">
                  {/* {formatCurrency(totals.grandTotal)} */}
                  {formatCurrency(payableTotal)}
                </span>
              </div>

              <button
                className="pos-exact-pay-btn"
                onClick={() => setPaymentOpen(true)}
                disabled={
                  cart.length === 0 ||
                  loadingReturnCredit ||
                  promotionPreviewLoading
                }
              >
                <FiCreditCard />
                <span>Pay Now</span>
              </button>
            </div>
          </div>
        </div>

        <div className="pos-terminal-statusbar" aria-label="POS device and shortcut status">
          <div className="pos-terminal-devices">
            <span>
              <strong>SCANNER</strong>
              {scannerEnabled ? "Enabled" : "Disabled"}
            </span>
            <span>
              <strong>WEIGHING SCALE</strong>
              Not configured
            </span>
            <span>
              <strong>PRINTER</strong>
              {autoPrint ? `Auto · ${printerWidth}mm` : "Manual"}
            </span>
            <span>
              <strong>EDC / CARD TERMINAL</strong>
              Not configured
            </span>
          </div>
          <div className="pos-terminal-shortcuts">
            F2 Search · F3 Price Check · F4 Customer · F5 Quantity · F8 Pay · F9 New Bill · F10 Hold
          </div>
        </div>

        {shiftModalOpen && (
          <div
            className="pos-terminal-overlay"
            onClick={(e) => {
              if (e.target === e.currentTarget) setShiftModalOpen(false);
            }}
          >
            <section
              className="pos-terminal-dialog pos-shift-open-dialog"
              role="dialog"
              aria-modal="true"
              aria-labelledby="pos-shift-open-title"
            >
              <header className="pos-terminal-dialog-header pos-terminal-dialog-header--green">
                <div className="pos-terminal-kicker">POS Shift Management</div>
                <h2 id="pos-shift-open-title">Open New Shift</h2>
                <span>
                  LANE 01 · TERMINAL POS-TERMINAL-1 · DRAWER NOT CONFIGURED ·{" "}
                  {new Date().toLocaleString("en-IN")}
                </span>
              </header>
              <div className="pos-terminal-dialog-body">
                <div className="pos-terminal-operator">
                  <div>
                    <span>OPERATOR</span>
                    <strong>
                      {billingUser?.name || billingUser?.username || "Signed-in user"}
                    </strong>
                  </div>
                  <div>
                    <span>OPERATOR ID</span>
                    <code>#{billingUser?.id || "—"}</code>
                  </div>
                  <div>
                    <span>WORKSTATION</span>
                    <code>POS COUNTER 01</code>
                  </div>
                  <div>
                    <span>ASSIGNED TILL</span>
                    <code>LANE 01</code>
                  </div>
                </div>
                <CashDenominationCounter
                  counts={openingDenominations}
                  onChange={setOpeningDenominations}
                  onEnter={handleStartShift}
                  title="Opening physical count · required"
                  autoFocus
                />
                <div className="pos-shift-presets" aria-label="Opening float presets">
                  {[500, 1000, 2000].map((amount) => (
                    <button
                      key={amount}
                      type="button"
                      onClick={() => {
                        const counts = createEmptyDenominationCounts();
                        counts["500"] = String(amount / 500);
                        setOpeningDenominations(counts);
                      }}
                    >
                      ₹{amount.toLocaleString("en-IN")}
                      {amount === 1000 ? " · STANDARD" : ""}
                    </button>
                  ))}
                  <button type="button" disabled title="Configure a standard float in settings">
                    STANDARD FLOAT · NOT SET
                  </button>
                </div>
                <div className="pos-shift-opening-total" aria-live="polite">
                  <span>CALCULATED OPENING FLOAT</span>
                  <strong>
                    {Number.isFinite(openingFloatTotal)
                      ? formatCurrency(openingFloatTotal)
                      : "INVALID COUNT"}
                  </strong>
                  <b>
                    {areDenominationCountsValid(openingDenominations)
                      ? "COUNT VERIFIED"
                      : "CHECK COUNTS"}
                  </b>
                </div>
                <div className="pos-shift-policy">
                  Count the notes and coins. The opening float is calculated from
                  the denomination counts and saved with this shift.
                </div>
              </div>
              <footer className="pos-terminal-dialog-footer">
                <button
                  type="button"
                  className="pos-terminal-button pos-terminal-button--quiet"
                  onClick={() => setShiftModalOpen(false)}
                >
                  Cancel <kbd>Esc</kbd>
                </button>
                <button
                  type="button"
                  className="pos-terminal-button pos-terminal-button--green"
                  onClick={handleStartShift}
                  disabled={!areDenominationCountsValid(openingDenominations)}
                >
                  Start Shift <kbd>Enter</kbd>
                </button>
              </footer>
            </section>
          </div>
        )}

        {/* ═══ SHIFT CLOSE MODAL ═══ */}
        {shiftCloseModal && activeShift && (
          <div
            className="pos-terminal-overlay"
            onKeyDown={(event) => {
              if (event.key === "F10") {
                event.preventDefault();
                if (
                  shiftCloseConfirmed &&
                  areDenominationCountsValid(closingDenominations)
                ) {
                  handleEndShift();
                }
              }
            }}
            onClick={(e) => {
              if (e.target === e.currentTarget) setShiftCloseModal(false);
            }}
          >
            <section
              className="pos-terminal-dialog pos-shift-close-dialog"
              role="dialog"
              aria-modal="true"
              aria-labelledby="pos-shift-close-title"
            >
              <header className="pos-terminal-dialog-header pos-terminal-dialog-header--red">
                <div
                  className="pos-terminal-kicker"
                >
                  Cash Drawer Reconciliation
                </div>
                <h2 id="pos-shift-close-title">
                  Close Shift #{activeShift.id}
                </h2>
                <span>
                  END OF SHIFT · {activeShift.terminalId || "Terminal"} ·{" "}
                  {activeShift.user?.name ||
                    billingUser?.name ||
                    billingUser?.username ||
                    "Signed-in user"}
                  {activeShift.openedAt
                    ? ` · Opened ${new Date(activeShift.openedAt).toLocaleString("en-IN")}`
                    : ""}
                  {" · Closing "}
                  {new Date().toLocaleString("en-IN")}
                </span>
              </header>
              <div className="pos-terminal-dialog-body pos-shift-close-body">
                <div
                  className="pos-shift-audit-summary"
                >
                  <div className="pos-shift-audit-card pos-shift-audit-card--green">
                    <div className="pos-terminal-kicker">
                      Opening Float
                    </div>
                    <strong>
                      {formatCurrency(activeShift.openingFloat || 0)}
                    </strong>
                  </div>
                  <div className="pos-shift-audit-card pos-shift-audit-card--blue">
                    <div className="pos-terminal-kicker">
                      Total Bills
                    </div>
                    <strong>
                      {activeShift.totalSalesCount || 0} bills
                    </strong>
                  </div>
                  <div className="pos-shift-audit-card">
                    <div className="pos-terminal-kicker">REGISTER TENDER</div>
                    <strong>{formatCurrency(recordedShiftSales)}</strong>
                  </div>
                  <div className="pos-shift-audit-card">
                    <div className="pos-terminal-kicker">AVG. TENDER / BILL</div>
                    <strong>
                      {activeShift.totalSalesCount
                        ? formatCurrency(averageRecordedTender)
                        : "—"}
                    </strong>
                  </div>
                  <div className="pos-shift-audit-card">
                    <div className="pos-terminal-kicker">VOID COUNT</div>
                    <strong>Not tracked</strong>
                  </div>
                </div>
                <div
                  className="pos-shift-payment-breakdown"
                >
                  <div className="pos-shift-payment-card">
                    <div className="pos-terminal-kicker">
                      CASH
                    </div>
                    <strong>
                      {formatCurrency(activeShift.cashSalesTotal || 0)}
                    </strong>
                    <small>Transaction count not tracked</small>
                  </div>
                  <div className="pos-shift-payment-card">
                    <div className="pos-terminal-kicker">
                      CARD
                    </div>
                    <strong>
                      {formatCurrency(activeShift.cardSalesTotal || 0)}
                    </strong>
                    <small>Transaction count not tracked</small>
                  </div>
                  <div className="pos-shift-payment-card">
                    <div className="pos-terminal-kicker">
                      UPI
                    </div>
                    <strong>
                      {formatCurrency(activeShift.upiSalesTotal || 0)}
                    </strong>
                    <small>Transaction count not tracked</small>
                  </div>
                  <div className="pos-shift-payment-card">
                    <div className="pos-terminal-kicker">
                      OTHER
                    </div>
                    <strong>
                      {formatCurrency(activeShift.otherSalesTotal || 0)}
                    </strong>
                    <small>Transaction count not tracked</small>
                  </div>
                </div>
                <CashDenominationCounter
                  counts={closingDenominations}
                  onChange={setClosingDenominations}
                  onEnter={() => {
                    if (shiftCloseConfirmed) handleEndShift();
                  }}
                  title="Actual physical cash in drawer · required"
                  autoFocus
                />
                <div className="pos-shift-expected-cash">
                  <span>
                    <strong>Expected Cash</strong>
                    <small>
                      Opening float + cash sales + cash-in − cash-out − refunds
                    </small>
                  </span>
                  <strong>{formatCurrency(expectedClosingCash)}</strong>
                </div>
                <div className="pos-shift-actual-cash">
                  <span>ACTUAL CASH COUNTED</span>
                  <strong>
                    {Number.isFinite(closingCashTotal)
                      ? formatCurrency(closingCashTotal)
                      : "INVALID COUNT"}
                  </strong>
                </div>
                {Number.isFinite(closingCashVariance) && (
                  <div
                    className={`pos-shift-variance ${
                      Math.abs(closingCashVariance) < 0.01
                        ? "is-matched"
                        : closingCashVariance < 0
                          ? "is-short"
                          : "is-surplus"
                    }`}
                    role="status"
                  >
                    <span>
                      {Math.abs(closingCashVariance) < 0.01
                        ? "PERFECT MATCH"
                        : closingCashVariance < 0
                          ? "SHORTAGE DETECTED"
                          : "SURPLUS DETECTED"}
                    </span>
                    <strong>
                      {Math.abs(closingCashVariance) < 0.01
                        ? formatCurrency(0)
                        : formatCurrency(Math.abs(closingCashVariance))}
                    </strong>
                  </div>
                )}
                <label className="pos-shift-confirm">
                  <input
                    type="checkbox"
                    checked={shiftCloseConfirmed}
                    onChange={(event) =>
                      setShiftCloseConfirmed(event.target.checked)
                    }
                  />
                  <span>
                    I confirm that the physical cash count is accurate.
                  </span>
                </label>
                <footer className="pos-terminal-dialog-footer">
                  <button
                    type="button"
                    className="pos-terminal-button pos-terminal-button--quiet"
                    onClick={() => setShiftCloseModal(false)}
                  >
                    Cancel <kbd>Esc</kbd>
                  </button>
                  <button
                    type="button"
                    className="pos-terminal-button pos-terminal-button--red"
                    onClick={handleEndShift}
                    disabled={
                      !shiftCloseConfirmed ||
                      !areDenominationCountsValid(closingDenominations)
                    }
                  >
                    CLOSE SHIFT <kbd>F10</kbd>
                  </button>
                </footer>
              </div>
            </section>
          </div>
        )}

        {/* ═══ HELD CARTS DRAWER ═══ */}
        {holdDrawerOpen && (
          <div
            className="pos-exact-drawer-overlay"
            onClick={(e) => {
              if (e.target === e.currentTarget) setHoldDrawerOpen(false);
            }}
          >
            <div className="pos-exact-drawer">
              <div className="pos-exact-drawer-header">
                <h3>📋 Held Carts ({holdCarts.length})</h3>
                <button onClick={() => setHoldDrawerOpen(false)}>✕</button>
              </div>
              <div className="pos-exact-drawer-body">
                {holdCarts.length === 0 ? (
                  <div className="pos-exact-empty-drawer">
                    No held sales found
                  </div>
                ) : (
                  holdCarts.map((h) => {
                    const items = Array.isArray(h.cartData) ? h.cartData : [];
                    return (
                      <div key={h.id} className="pos-exact-held-item">
                        <div className="pos-exact-held-top">
                          <div>
                            <strong>
                              {h.customerName || "Walk-in Customer"}
                            </strong>
                            <div>
                              {h.holdNumber} · {items.length} items
                            </div>
                          </div>
                          <div className="pos-exact-held-total">
                            {formatCurrency(h.totalAmount || 0)}
                          </div>
                        </div>
                        <div className="pos-exact-held-actions">
                          <button
                            className="pos-exact-btn-primary"
                            onClick={() => handleResumeCart(h.id)}
                          >
                            Resume
                          </button>
                          <button
                            className="pos-exact-btn-subtle"
                            onClick={() => {
                              cancelHoldCart(h.id);
                              toast.success("Held cart cancelled");
                            }}
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
